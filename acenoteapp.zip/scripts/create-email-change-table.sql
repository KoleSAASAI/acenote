-- Create email change requests table for custom email change handling
CREATE TABLE IF NOT EXISTS email_change_requests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    old_email TEXT NOT NULL,
    new_email TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'expired')),
    token TEXT DEFAULT gen_random_uuid(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '24 hours')
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_email_change_requests_user_id ON email_change_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_email_change_requests_token ON email_change_requests(token);

-- Enable RLS
ALTER TABLE email_change_requests ENABLE ROW LEVEL SECURITY;

-- Create policy for users to see their own requests
CREATE POLICY "Users can view their own email change requests" ON email_change_requests
    FOR SELECT USING (auth.uid() = user_id);

-- Create policy for users to insert their own requests
CREATE POLICY "Users can create their own email change requests" ON email_change_requests
    FOR INSERT WITH CHECK (auth.uid() = user_id);
