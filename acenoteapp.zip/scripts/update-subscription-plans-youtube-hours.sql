-- Update subscription plans to reflect YouTube transcription hours
UPDATE subscription_plans 
SET 
  max_youtube_duration_minutes = 60, -- 1 hour for free plan
  updated_at = NOW()
WHERE name = 'Free Plan';

UPDATE subscription_plans 
SET 
  max_youtube_duration_minutes = 600, -- 10 hours for ultimate plan
  updated_at = NOW()
WHERE name = 'Ultimate Plan';

-- Add YouTube transcription tracking to user_usage table
ALTER TABLE user_usage 
ADD COLUMN IF NOT EXISTS youtube_minutes_used_this_month INTEGER DEFAULT 0;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_user_usage_youtube_minutes 
ON user_usage(user_id, month_year, youtube_minutes_used_this_month);
