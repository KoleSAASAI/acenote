-- Assign Free Plan to all existing users who don't have a subscription
INSERT INTO public.user_subscriptions (user_id, plan_id, status)
SELECT 
  u.id,
  sp.id,
  'active'
FROM auth.users u
CROSS JOIN public.subscription_plans sp
WHERE sp.name = 'Free Plan'
  AND NOT EXISTS (
    SELECT 1 FROM public.user_subscriptions us 
    WHERE us.user_id = u.id
  );

-- Initialize usage tracking for existing users
INSERT INTO public.user_usage (user_id, month_year)
SELECT 
  u.id,
  TO_CHAR(NOW(), 'YYYY-MM')
FROM auth.users u
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_usage uu 
  WHERE uu.user_id = u.id 
    AND uu.month_year = TO_CHAR(NOW(), 'YYYY-MM')
);
