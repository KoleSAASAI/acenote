-- Enable RLS on profiles table
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own profile
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

-- Policy: Users can update their own profile
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Policy: Users can insert their own profile
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Enable RLS on uploads table
ALTER TABLE uploads ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own uploads
CREATE POLICY "Users can view own uploads" ON uploads
  FOR SELECT USING (auth.uid() = user_id);

-- Policy: Users can insert their own uploads
CREATE POLICY "Users can insert own uploads" ON uploads
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own uploads
CREATE POLICY "Users can update own uploads" ON uploads
  FOR UPDATE USING (auth.uid() = user_id);

-- Policy: Users can delete their own uploads
CREATE POLICY "Users can delete own uploads" ON uploads
  FOR DELETE USING (auth.uid() = user_id);

-- Enable RLS on flashcards table
ALTER TABLE flashcards ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view flashcards from their uploads
CREATE POLICY "Users can view own flashcards" ON flashcards
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Policy: Users can insert flashcards for their uploads
CREATE POLICY "Users can insert own flashcards" ON flashcards
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Policy: Users can update flashcards from their uploads
CREATE POLICY "Users can update own flashcards" ON flashcards
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Policy: Users can delete flashcards from their uploads
CREATE POLICY "Users can delete own flashcards" ON flashcards
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );
