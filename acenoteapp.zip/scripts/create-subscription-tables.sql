-- Create subscription plans table
CREATE TABLE IF NOT EXISTS public.subscription_plans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  price_monthly DECIMAL(10,2) NOT NULL DEFAULT 0,
  price_yearly DECIMAL(10,2) NOT NULL DEFAULT 0,
  max_uploads_per_month INTEGER NOT NULL DEFAULT 1,
  max_uploads_per_day INTEGER NOT NULL DEFAULT 1,
  max_file_size_mb INTEGER NOT NULL DEFAULT 50,
  max_youtube_duration_minutes INTEGER NOT NULL DEFAULT 60,
  max_flashcards INTEGER NOT NULL DEFAULT 50,
  max_quiz_questions INTEGER NOT NULL DEFAULT 10,
  max_chat_interactions INTEGER NOT NULL DEFAULT 10,
  max_tokens_per_month INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user subscriptions table
CREATE TABLE IF NOT EXISTS public.user_subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  plan_id UUID REFERENCES public.subscription_plans(id) NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  stripe_subscription_id TEXT,
  current_period_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  current_period_end TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '1 month'),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create usage tracking table
CREATE TABLE IF NOT EXISTS public.user_usage (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  month_year TEXT NOT NULL, -- Format: YYYY-MM
  uploads_this_month INTEGER DEFAULT 0,
  uploads_this_day INTEGER DEFAULT 0,
  chat_interactions_this_month INTEGER DEFAULT 0,
  tokens_used_this_month INTEGER DEFAULT 0,
  last_upload_date DATE,
  last_chat_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, month_year)
);

-- Insert default plans
INSERT INTO public.subscription_plans (
  name, description, price_monthly, price_yearly, 
  max_uploads_per_month, max_uploads_per_day, max_file_size_mb, 
  max_youtube_duration_minutes, max_flashcards, max_quiz_questions, 
  max_chat_interactions, max_tokens_per_month
) VALUES 
(
  'Free Plan', 
  'Limited uploads and AI features', 
  0.00, 
  0.00,
  1, -- 1 upload per month total
  1, -- 1 upload per day
  50, -- 50MB max file size
  60, -- 1 hour max YouTube
  50, -- 50 flashcards max
  10, -- 10 quiz questions max
  10, -- 10 chat interactions max
  1000
),
(
  'Ultimate Plan', 
  'Unlimited uploads and AI features', 
  9.99, 
  59.88,
  999, -- Effectively unlimited (high number)
  15, -- 15 uploads per day max
  1024, -- 1GB max file size
  600, -- 600 minutes max YouTube duration
  999, -- Effectively unlimited flashcards
  999, -- Effectively unlimited quiz questions
  999, -- Effectively unlimited chat interactions
  20000
) ON CONFLICT (name) DO UPDATE SET
  description = EXCLUDED.description,
  price_monthly = EXCLUDED.price_monthly,
  price_yearly = EXCLUDED.price_yearly,
  max_uploads_per_month = EXCLUDED.max_uploads_per_month,
  max_uploads_per_day = EXCLUDED.max_uploads_per_day,
  max_file_size_mb = EXCLUDED.max_file_size_mb,
  max_youtube_duration_minutes = EXCLUDED.max_youtube_duration_minutes,
  max_flashcards = EXCLUDED.max_flashcards,
  max_quiz_questions = EXCLUDED.max_quiz_questions,
  max_chat_interactions = EXCLUDED.max_chat_interactions,
  max_tokens_per_month = EXCLUDED.max_tokens_per_month,
  updated_at = NOW();

-- Create function to assign free plan to new users
CREATE OR REPLACE FUNCTION assign_free_plan_to_new_user()
RETURNS TRIGGER AS $$
DECLARE
  free_plan_id UUID;
BEGIN
  -- Get the free plan ID
  SELECT id INTO free_plan_id FROM public.subscription_plans WHERE name = 'Free Plan' LIMIT 1;
  
  -- Assign free plan to new user
  INSERT INTO public.user_subscriptions (user_id, plan_id, status)
  VALUES (NEW.id, free_plan_id, 'active');
  
  -- Initialize usage tracking
  INSERT INTO public.user_usage (user_id, month_year)
  VALUES (NEW.id, TO_CHAR(NOW(), 'YYYY-MM'));
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new user registration
DROP TRIGGER IF EXISTS assign_free_plan_trigger ON auth.users;
CREATE TRIGGER assign_free_plan_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION assign_free_plan_to_new_user();

-- Enable RLS
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_usage ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can view subscription plans" ON public.subscription_plans;
DROP POLICY IF EXISTS "Users can view own subscription" ON public.user_subscriptions;
DROP POLICY IF EXISTS "Users can view own usage" ON public.user_usage;
DROP POLICY IF EXISTS "Users can update own usage" ON public.user_usage;
DROP POLICY IF EXISTS "Users can insert own usage" ON public.user_usage;

-- Create RLS policies
CREATE POLICY "Anyone can view subscription plans" ON public.subscription_plans
  FOR SELECT USING (true);

CREATE POLICY "Users can view own subscription" ON public.user_subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view own usage" ON public.user_usage
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own usage" ON public.user_usage
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own usage" ON public.user_usage
  FOR INSERT WITH CHECK (auth.uid() = user_id);
