-- Create email change requests table
CREATE TABLE IF NOT EXISTS public.email_change_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  old_email TEXT NOT NULL,
  new_email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'expired')),
  token TEXT,
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '24 hours'),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.email_change_requests ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own email change requests" ON public.email_change_requests;
DROP POLICY IF EXISTS "Users can insert own email change requests" ON public.email_change_requests;
DROP POLICY IF EXISTS "Users can update own email change requests" ON public.email_change_requests;

-- Create RLS policies
CREATE POLICY "Users can view own email change requests" ON public.email_change_requests
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own email change requests" ON public.email_change_requests
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own email change requests" ON public.email_change_requests
  FOR UPDATE USING (auth.uid() = user_id);
