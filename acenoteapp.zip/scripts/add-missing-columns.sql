-- Add missing columns to existing tables
ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_tokens_per_month INTEGER DEFAULT 0;

-- Update existing plans with token limits
UPDATE public.subscription_plans 
SET max_tokens_per_month = 1000
WHERE name = 'Free Plan';

UPDATE public.subscription_plans 
SET max_tokens_per_month = 20000
WHERE name = 'Ultimate Plan';

-- Also update YouTube duration limits
UPDATE public.subscription_plans 
SET max_youtube_duration_minutes = 600
WHERE name = 'Ultimate Plan';

-- Add tokens_used_this_month column to user_usage if it doesn't exist
ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS tokens_used_this_month INTEGER DEFAULT 0;
