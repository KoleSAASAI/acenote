-- Add all missing columns to subscription_plans table
ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_tokens_per_month INTEGER DEFAULT 0;

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_uploads_per_day INTEGER DEFAULT 1;

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_youtube_duration_minutes INTEGER DEFAULT 60;

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_flashcards INTEGER DEFAULT 50;

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_quiz_questions INTEGER DEFAULT 10;

ALTER TABLE public.subscription_plans 
ADD COLUMN IF NOT EXISTS max_chat_interactions INTEGER DEFAULT 10;

-- Add missing columns to user_usage table if it exists
ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS tokens_used_this_month INTEGER DEFAULT 0;

ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS uploads_this_day INTEGER DEFAULT 0;

ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS chat_interactions_this_month INTEGER DEFAULT 0;

ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS last_upload_date DATE;

ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS last_chat_date DATE;

-- Update existing plans with proper values
UPDATE public.subscription_plans 
SET 
  max_tokens_per_month = 1000,
  max_uploads_per_day = 1,
  max_youtube_duration_minutes = 60,
  max_flashcards = 50,
  max_quiz_questions = 10,
  max_chat_interactions = 10,
  updated_at = NOW()
WHERE name = 'Free Plan';

UPDATE public.subscription_plans 
SET 
  max_tokens_per_month = 20000,
  max_uploads_per_day = 15,
  max_youtube_duration_minutes = 600,
  max_flashcards = 999,
  max_quiz_questions = 999,
  max_chat_interactions = 999,
  updated_at = NOW()
WHERE name = 'Ultimate Plan';

-- Insert plans if they don't exist
INSERT INTO public.subscription_plans (
  name, description, price_monthly, price_yearly, 
  max_uploads_per_month, max_uploads_per_day, max_file_size_mb, 
  max_youtube_duration_minutes, max_flashcards, max_quiz_questions, 
  max_chat_interactions, max_tokens_per_month
) 
SELECT 
  'Free Plan', 
  'Limited uploads and AI features', 
  0.00, 
  0.00,
  1, -- 1 upload per month total
  1, -- 1 upload per day
  50, -- 50MB max file size
  60, -- 1 hour max YouTube
  50, -- 50 flashcards max
  10, -- 10 quiz questions max
  10, -- 10 chat interactions max
  1000 -- 1000 tokens per month
WHERE NOT EXISTS (SELECT 1 FROM public.subscription_plans WHERE name = 'Free Plan');

INSERT INTO public.subscription_plans (
  name, description, price_monthly, price_yearly, 
  max_uploads_per_month, max_uploads_per_day, max_file_size_mb, 
  max_youtube_duration_minutes, max_flashcards, max_quiz_questions, 
  max_chat_interactions, max_tokens_per_month
) 
SELECT 
  'Ultimate Plan', 
  'Unlimited uploads and AI features', 
  9.99, 
  59.88,
  999, -- Effectively unlimited (high number)
  15, -- 15 uploads per day max
  1024, -- 1GB max file size
  600, -- 10 hours max YouTube duration
  999, -- Effectively unlimited flashcards
  999, -- Effectively unlimited quiz questions
  999, -- Effectively unlimited chat interactions
  20000 -- 20000 tokens per month
WHERE NOT EXISTS (SELECT 1 FROM public.subscription_plans WHERE name = 'Ultimate Plan');
