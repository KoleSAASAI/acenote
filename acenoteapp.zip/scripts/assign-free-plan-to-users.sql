-- Function to assign free plan to new users
CREATE OR REPLACE FUNCTION public.assign_free_plan_to_user()
RETURNS TRIGGER AS $$
DECLARE
  free_plan_id UUID;
BEGIN
  -- Get the Free Plan ID
  SELECT id INTO free_plan_id 
  FROM public.subscription_plans 
  WHERE name = 'Free Plan' 
  LIMIT 1;

  -- Insert user subscription with Free Plan
  IF free_plan_id IS NOT NULL THEN
    INSERT INTO public.user_subscriptions (
      user_id,
      plan_id,
      status,
      current_period_start,
      current_period_end
    ) VALUES (
      NEW.id,
      free_plan_id,
      'active',
      NOW(),
      NOW() + INTERVAL '1 year' -- Free plan doesn't expire
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created_assign_plan ON auth.users;

-- Create trigger to assign free plan to new users
CREATE TRIGGER on_auth_user_created_assign_plan
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.assign_free_plan_to_user();

-- Assign free plan to existing users who don't have a subscription
INSERT INTO public.user_subscriptions (user_id, plan_id, status, current_period_start, current_period_end)
SELECT 
  u.id,
  sp.id,
  'active',
  NOW(),
  NOW() + INTERVAL '1 year'
FROM auth.users u
CROSS JOIN public.subscription_plans sp
WHERE sp.name = 'Free Plan'
  AND NOT EXISTS (
    SELECT 1 FROM public.user_subscriptions us 
    WHERE us.user_id = u.id
  );
