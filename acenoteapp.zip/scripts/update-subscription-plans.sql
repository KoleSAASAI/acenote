-- Update subscription plans with new limits
UPDATE subscription_plans 
SET 
  max_youtube_duration_minutes = 600, -- 10 hours for Ultimate Plan
  max_tokens_per_month = 20000
WHERE name = 'Ultimate Plan';

UPDATE subscription_plans 
SET 
  max_youtube_duration_minutes = 60 -- 1 hour for Free Plan
WHERE name = 'Free Plan';

-- Add token limit column if it doesn't exist
ALTER TABLE subscription_plans 
ADD COLUMN IF NOT EXISTS max_tokens_per_month INTEGER DEFAULT 0;
