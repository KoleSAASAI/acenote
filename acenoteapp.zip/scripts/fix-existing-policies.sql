-- Drop all existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

DROP POLICY IF EXISTS "Users can view own uploads" ON public.uploads;
DROP POLICY IF EXISTS "Users can insert own uploads" ON public.uploads;
DROP POLICY IF EXISTS "Users can update own uploads" ON public.uploads;
DROP POLICY IF EXISTS "Users can delete own uploads" ON public.uploads;

DROP POLICY IF EXISTS "Users can view own notes" ON public.notes;
DROP POLICY IF EXISTS "Users can insert own notes" ON public.notes;

DROP POLICY IF EXISTS "Users can view own flashcards" ON public.flashcards;
DROP POLICY IF EXISTS "Users can insert own flashcards" ON public.flashcards;
DROP POLICY IF EXISTS "Users can update own flashcards" ON public.flashcards;
DROP POLICY IF EXISTS "Users can delete own flashcards" ON public.flashcards;

DROP POLICY IF EXISTS "Users can view own quiz questions" ON public.quiz_questions;
DROP POLICY IF EXISTS "Users can insert own quiz questions" ON public.quiz_questions;

DROP POLICY IF EXISTS "Users can view own chat messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Users can insert own chat messages" ON public.chat_messages;

-- Recreate all policies
-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Uploads policies
CREATE POLICY "Users can view own uploads" ON public.uploads
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own uploads" ON public.uploads
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own uploads" ON public.uploads
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own uploads" ON public.uploads
  FOR DELETE USING (auth.uid() = user_id);

-- Notes policies
CREATE POLICY "Users can view own notes" ON public.notes
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = notes.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own notes" ON public.notes
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = notes.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Flashcards policies
CREATE POLICY "Users can view own flashcards" ON public.flashcards
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own flashcards" ON public.flashcards
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own flashcards" ON public.flashcards
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own flashcards" ON public.flashcards
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = flashcards.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Quiz questions policies
CREATE POLICY "Users can view own quiz questions" ON public.quiz_questions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = quiz_questions.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own quiz questions" ON public.quiz_questions
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.uploads 
      WHERE uploads.id = quiz_questions.upload_id 
      AND uploads.user_id = auth.uid()
    )
  );

-- Chat messages policies
CREATE POLICY "Users can view own chat messages" ON public.chat_messages
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own chat messages" ON public.chat_messages
  FOR INSERT WITH CHECK (auth.uid() = user_id);
