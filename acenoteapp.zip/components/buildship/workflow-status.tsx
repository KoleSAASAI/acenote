"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Clock, AlertCircle, Loader2 } from "lucide-react"

interface WorkflowStatusProps {
  workflowId: string
  uploadId: string
  onComplete?: (result: any) => void
}

export function WorkflowStatus({ workflowId, uploadId, onComplete }: WorkflowStatusProps) {
  const [status, setStatus] = useState<"processing" | "completed" | "failed">("processing")
  const [progress, setProgress] = useState(0)
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`/api/buildship/status/${workflowId}`)
        const data = await response.json()

        setStatus(data.status)
        setProgress(data.progress || 0)
        setLogs(data.logs || [])

        if (data.status === "completed" && onComplete) {
          onComplete(data.result)
        }
      } catch (error) {
        console.error("Failed to check workflow status:", error)
      }
    }

    const interval = setInterval(checkStatus, 2000) // Check every 2 seconds
    checkStatus() // Initial check

    return () => clearInterval(interval)
  }, [workflowId, onComplete])

  const getStatusIcon = () => {
    switch (status) {
      case "processing":
        return <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "failed":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      default:
        return <Clock className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusColor = () => {
    switch (status) {
      case "processing":
        return "bg-blue-500"
      case "completed":
        return "bg-green-500"
      case "failed":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          BuildShip Workflow Status
          <Badge variant="outline" className={getStatusColor()}>
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>

        {logs.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-2">Workflow Logs</h4>
            <div className="bg-gray-50 rounded-md p-3 max-h-40 overflow-y-auto">
              {logs.map((log, index) => (
                <div key={index} className="text-xs text-gray-600 mb-1">
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="text-xs text-gray-500">Workflow ID: {workflowId}</div>
      </CardContent>
    </Card>
  )
}
