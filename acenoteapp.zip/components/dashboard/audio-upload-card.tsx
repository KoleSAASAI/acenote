"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, Mic, X } from "lucide-react"
import { UpgradeModal } from "./upgrade-modal"

interface AudioUploadCardProps {
  onAudioUpload: (fileName: string) => void
}

export function AudioUploadCard({ onAudioUpload }: AudioUploadCardProps) {
  const [isDragOver, setIsDragOver] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Mock function to check if user has reached upload limit
  const checkUploadLimit = async () => {
    const userPlan = "free" // This would come from your auth context
    const uploadsThisMonth = 1 // This would come from your backend

    if (userPlan === "free" && uploadsThisMonth >= 1) {
      return false // User has reached limit - always show upgrade modal
    }
    return true // User can upload
  }

  // Update the handleFileSelect function to always check limits
  const handleFileSelect = async (file: File) => {
    const canUpload = await checkUploadLimit()

    if (!canUpload) {
      setShowUpgradeModal(true)
      return // Stop the upload process and show upgrade modal
    }

    // Check file size limit for free users (50MB)
    const maxSize = 50 * 1024 * 1024 // 50MB in bytes
    if (file.size > maxSize) {
      setShowUpgradeModal(true)
      return // Stop the upload process and show upgrade modal
    }

    setSelectedFile(file)
    onAudioUpload(file.name)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  return (
    <>
      <div
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
          isDragOver
            ? "border-emerald-400 bg-emerald-500/10"
            : "border-slate-600 hover:border-slate-500 bg-slate-800/30"
        }`}
        onDragOver={(e) => {
          e.preventDefault()
          setIsDragOver(true)
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".mp3,.wav,.m4a,.aac,.ogg"
          onChange={handleFileInputChange}
          className="hidden"
        />

        {selectedFile ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3">
              <Mic className="h-8 w-8 text-emerald-400" />
              <span className="text-white font-medium">{selectedFile.name}</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedFile(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <Upload className="h-12 w-12 text-slate-400" />
            </div>
            <div>
              <p className="text-white font-medium mb-2">Drop your audio files here</p>
              <p className="text-slate-400 text-sm mb-4">or</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Browse Files
              </Button>
            </div>
            <p className="text-xs text-slate-500">Supports MP3, WAV, M4A, AAC, OGG (Max 50MB)</p>
          </div>
        )}
      </div>

      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} showLimitMessage={true} />
    </>
  )
}
