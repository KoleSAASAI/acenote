"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RotateCcw, Shuffle, Eye, CheckCircle, X, Check, Trophy, RefreshCw } from "lucide-react"

const flashcards = [
  {
    front: "What is photosynthesis?",
    back: "The process by which plants convert light energy into chemical energy, producing glucose and oxygen from carbon dioxide and water.",
  },
  {
    front: "Where does photosynthesis occur?",
    back: "In chloroplasts, specifically in the thylakoid membranes (light reactions) and stroma (Calvin cycle).",
  },
  {
    front: "What are the two main stages of photosynthesis?",
    back: "Light reactions (photo part) and the Calvin cycle (synthesis part).",
  },
  {
    front: "What does chlorophyll absorb?",
    back: "Light energy, primarily red and blue wavelengths, while reflecting green light.",
  },
  {
    front: "What is the overall equation for photosynthesis?",
    back: "6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂",
  },
]

export function FlashcardView() {
  const [currentCard, setCurrentCard] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [correctCards, setCorrectCards] = useState<number[]>([])
  const [wrongCards, setWrongCards] = useState<number[]>([])
  const [currentDeck, setCurrentDeck] = useState<number[]>([0, 1, 2, 3, 4]) // Initial deck with all card indices
  const [deckIndex, setDeckIndex] = useState(0) // Current position in the deck
  const [isReviewingWrong, setIsReviewingWrong] = useState(false)
  const [completedSets, setCompletedSets] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  // Add keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        e.preventDefault()
        if (!isFlipped && !isTransitioning) {
          flipCard()
        }
      } else if (e.code === "ArrowLeft") {
        e.preventDefault()
        if (isFlipped && !isTransitioning) {
          handleWrong()
        }
      } else if (e.code === "ArrowRight") {
        e.preventDefault()
        if (isFlipped && !isTransitioning) {
          handleCorrect()
        }
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [isFlipped, currentCard, isTransitioning])

  const flipCard = () => {
    setIsFlipped(true)
  }

  const handleCorrect = () => {
    if (isTransitioning) return

    const actualCardIndex = currentDeck[deckIndex]

    // Update correct cards
    setCorrectCards((prev) => {
      const newCorrectCards = prev.includes(actualCardIndex) ? prev : [...prev, actualCardIndex]

      // Update wrong cards
      setWrongCards((prevWrong) => {
        const newWrongCards = prevWrong.filter((card) => card !== actualCardIndex)

        // Use setTimeout to ensure state updates are processed before checking completion
        setTimeout(() => {
          checkForNextStep(newCorrectCards, newWrongCards)
        }, 0)

        return newWrongCards
      })

      return newCorrectCards
    })
  }

  const handleWrong = () => {
    if (isTransitioning) return

    const actualCardIndex = currentDeck[deckIndex]

    // Update wrong cards
    setWrongCards((prev) => {
      const newWrongCards = prev.includes(actualCardIndex) ? prev : [...prev, actualCardIndex]

      // Update correct cards
      setCorrectCards((prevCorrect) => {
        const newCorrectCards = prevCorrect.filter((card) => card !== actualCardIndex)

        // Use setTimeout to ensure state updates are processed before checking completion
        setTimeout(() => {
          checkForNextStep(newCorrectCards, newWrongCards)
        }, 0)

        return newCorrectCards
      })

      return newWrongCards
    })
  }

  const checkForNextStep = (currentCorrectCards: number[], currentWrongCards: number[]) => {
    // Start transition
    setIsTransitioning(true)

    // Wait for a smooth transition
    setTimeout(() => {
      if (deckIndex < currentDeck.length - 1) {
        // Move to next card in current deck
        setDeckIndex(deckIndex + 1)
        setCurrentCard(currentDeck[deckIndex + 1])
        setIsFlipped(false) // Reset to show question first
      } else {
        // End of current deck - check if we need to review wrong cards
        const wrongCardsInCurrentDeck = currentWrongCards.filter((cardIndex) => currentDeck.includes(cardIndex))

        if (wrongCardsInCurrentDeck.length > 0) {
          // Start reviewing wrong cards
          setCurrentDeck(wrongCardsInCurrentDeck)
          setDeckIndex(0)
          setCurrentCard(wrongCardsInCurrentDeck[0])
          setIsFlipped(false) // Reset to show question first
          setIsReviewingWrong(true)
          setCompletedSets((prev) => prev + 1)
        } else {
          // Check if all cards are mastered
          if (currentCorrectCards.length === flashcards.length && currentWrongCards.length === 0) {
            // All cards mastered - completion state will be handled by the render
            setCompletedSets((prev) => prev + 1)
          } else {
            // Still have cards to review, but none in current deck
            setCompletedSets((prev) => prev + 1)
          }
        }
      }

      // End transition after content has changed
      setTimeout(() => {
        setIsTransitioning(false)
      }, 50)
    }, 400) // Longer delay for smoother transition
  }

  const resetProgress = () => {
    setCurrentCard(0)
    setDeckIndex(0)
    setIsFlipped(false)
    setCorrectCards([])
    setWrongCards([])
    setCurrentDeck([0, 1, 2, 3, 4])
    setIsReviewingWrong(false)
    setCompletedSets(0)
    setIsTransitioning(false)
  }

  const startReview = () => {
    resetProgress()
  }

  // Calculate progress based on correct answers only
  const totalUniqueCards = flashcards.length
  const uniqueCorrectCards = correctCards.length
  const progress = (uniqueCorrectCards / totalUniqueCards) * 100
  const remainingCards = totalUniqueCards - uniqueCorrectCards

  // Function to handle button clicks and remove focus
  const handleWrongClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    handleWrong()
    e.currentTarget.blur()
  }

  const handleCorrectClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    handleCorrect()
    e.currentTarget.blur()
  }

  const handleFlipClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!isTransitioning) {
      flipCard()
    }
    e.currentTarget.blur()
  }

  // Check if all cards are mastered
  const allCardsMastered = correctCards.length === flashcards.length && wrongCards.length === 0

  return (
    <div className="relative space-y-8" style={{ outline: "none" }} onFocus={(e) => e.preventDefault()} tabIndex={-1}>
      {/* Main Content - Blurred when completed */}
      <div className={allCardsMastered ? "filter blur-sm pointer-events-none" : ""}>
        {/* Header */}
        <div className="flex items-center justify-between" style={{ outline: "none" }} tabIndex={-1}>
          <div>
            <h2 className="text-xl font-semibold text-light" style={{ color: "#F8FAFC" }}>
              Flashcards {isReviewingWrong && <span className="text-orange-400">(Reviewing Wrong)</span>}
            </h2>
            <p className="text-gray-300">
              Card {deckIndex + 1} of {currentDeck.length}
              {completedSets > 0 && <span className="ml-2 text-sm">• Round {completedSets + 1}</span>}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" style={{ backgroundColor: "#3EF2B5", color: "#0F172A" }}>
              {uniqueCorrectCards} mastered
            </Badge>
            {wrongCards.length > 0 && (
              <Badge variant="secondary" style={{ backgroundColor: "#FF4444", color: "#F8FAFC" }}>
                {wrongCards.length} to review
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                resetProgress()
                e.currentTarget.blur()
              }}
              className="text-light hover:bg-card-custom focus:outline-none"
              style={{ color: "#F8FAFC" }}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => e.currentTarget.blur()}
              className="text-light hover:bg-card-custom focus:outline-none"
              style={{ color: "#F8FAFC" }}
            >
              <Shuffle className="h-4 w-4 mr-2" />
              Shuffle
            </Button>
          </div>
        </div>

        {/* Progress */}
        <div className="space-y-2" style={{ outline: "none" }} tabIndex={-1}>
          <div className="flex justify-between text-sm">
            <span className="text-light" style={{ color: "#F8FAFC" }}>
              Mastery Progress
            </span>
            <span className="text-light" style={{ color: "#F8FAFC" }}>
              {Math.round(progress)}%
            </span>
          </div>
          <div className="w-full bg-midnight-blue rounded-full h-2" style={{ backgroundColor: "#1E293B" }}>
            <div
              className="h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%`, backgroundColor: "#3EF2B5" }}
            ></div>
          </div>
        </div>

        {/* Flashcard with Smooth Transition */}
        <div className="flex justify-center py-8" style={{ outline: "none" }} tabIndex={-1}>
          <div
            className="relative w-full max-w-3xl"
            style={{
              height: "22rem",
            }}
          >
            {/* Card Container with Smooth Transition */}
            <div
              className={`relative w-full h-full transition-all duration-700 ease-out ${
                isTransitioning
                  ? "opacity-0 transform translate-x-8 scale-95"
                  : "opacity-100 transform translate-x-0 scale-100"
              }`}
              key={`${currentCard}-${isFlipped}`} // Force re-render on card change or flip
            >
              {!isFlipped ? (
                // Question Side
                <Card
                  className="w-full h-full cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl"
                  onClick={!isTransitioning ? flipCard : undefined}
                  style={{
                    backgroundColor: "#273349",
                    borderColor: "#94A3B8",
                    boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
                  }}
                >
                  <CardContent className="h-full flex items-center justify-center p-8">
                    <div className="text-center">
                      <div className="text-lg font-medium mb-4" style={{ color: "#3EF2B5" }}>
                        Question
                      </div>
                      <div className="text-xl leading-relaxed text-light" style={{ color: "#F8FAFC" }}>
                        {flashcards[currentCard].front}
                      </div>
                      <div className="mt-6 text-sm text-gray-400">Click to reveal answer</div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                // Answer Side with Flip Animation
                <Card
                  className="w-full h-full cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl"
                  style={{
                    backgroundColor: "#273349",
                    borderColor: "#94A3B8",
                    boxShadow: "0 0 20px rgba(62, 242, 181, 0.3), 0 8px 32px rgba(0, 0, 0, 0.3)",
                    animation: "flipIn 0.6s ease-out",
                  }}
                >
                  <CardContent className="h-full flex items-center justify-center p-8">
                    <div className="text-center">
                      <div className="text-lg font-medium mb-4" style={{ color: "#3EF2B5" }}>
                        Answer
                      </div>
                      <div className="text-xl leading-relaxed text-light" style={{ color: "#F8FAFC" }}>
                        {flashcards[currentCard].back}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>

        <style jsx>{`
          @keyframes flipIn {
            0% {
              transform: rotateY(-90deg);
              opacity: 0;
            }
            100% {
              transform: rotateY(0deg);
              opacity: 1;
            }
          }
        `}</style>

        {/* Navigation - Enhanced Button Group */}
        <div className="flex justify-center py-6" style={{ outline: "none" }} tabIndex={-1}>
          <Card
            className="inline-flex items-center p-2 gap-0.5"
            style={{
              backgroundColor: "#1E293B",
              border: "1px solid #374151",
              borderRadius: "12px",
              outline: "none",
            }}
            tabIndex={-1}
          >
            <Button
              variant="ghost"
              onClick={handleWrongClick}
              disabled={!isFlipped || isTransitioning}
              className="px-4 py-2 text-[#F8FAFC] hover:bg-[#273349] hover:text-[#F8FAFC] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 group"
              style={{ outline: "none", boxShadow: "none" }}
              title="Mark as wrong (←)"
              onFocus={(e) => e.currentTarget.blur()}
            >
              <span className="mr-2 text-xs opacity-60">←</span>
              <X className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform text-red-400" />
              Wrong
            </Button>

            <div className="w-px h-8 bg-[#374151] mx-1" />

            <Button
              onClick={handleFlipClick}
              disabled={isFlipped || isTransitioning}
              className="px-6 py-2 font-medium transition-all duration-200 hover:shadow-lg hover:shadow-[#1DB58B]/30 disabled:opacity-50 relative group"
              style={{
                backgroundColor: isFlipped ? "#1DB58B" : "#3EF2B5",
                color: "#0F172A",
                borderRadius: "8px",
                outline: "none",
                boxShadow: "none",
              }}
              title="Reveal answer (Space)"
              onFocus={(e) => e.currentTarget.blur()}
            >
              <div className="flex items-center">
                {isFlipped ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Answer Shown
                  </>
                ) : (
                  <>
                    <Eye className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
                    Show Answer
                    <kbd className="ml-2 px-1.5 py-0.5 text-xs bg-black/20 rounded border border-black/30">Space</kbd>
                  </>
                )}
              </div>
              {!isFlipped && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 animate-pulse opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              )}
            </Button>

            <div className="w-px h-8 bg-[#374151] mx-1" />

            <Button
              variant="ghost"
              onClick={handleCorrectClick}
              disabled={!isFlipped || isTransitioning}
              className="px-4 py-2 text-[#F8FAFC] hover:bg-[#273349] hover:text-[#F8FAFC] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 group"
              style={{ outline: "none", boxShadow: "none" }}
              title="Mark as correct (→)"
              onFocus={(e) => e.currentTarget.blur()}
            >
              Correct
              <Check className="h-4 w-4 ml-2 group-hover:scale-110 transition-transform text-green-400" />
              <span className="ml-2 text-xs opacity-60">→</span>
            </Button>
          </Card>
        </div>

        {/* Study Stats */}
        <div className="pt-8" style={{ outline: "none" }} tabIndex={-1}>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold" style={{ color: "#F8FAFC" }}>
                {flashcards.length}
              </div>
              <div className="text-sm" style={{ color: "#F8FAFC" }}>
                Total Cards
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold" style={{ color: "#3EF2B5" }}>
                {correctCards.length}
              </div>
              <div className="text-sm" style={{ color: "#F8FAFC" }}>
                Correct
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold" style={{ color: "#FF4444" }}>
                {wrongCards.length}
              </div>
              <div className="text-sm" style={{ color: "#F8FAFC" }}>
                Wrong
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold" style={{ color: "#F8FAFC" }}>
                {remainingCards}
              </div>
              <div className="text-sm" style={{ color: "#F8FAFC" }}>
                Remaining
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Completion Overlay */}
      {allCardsMastered && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <Card
            className="w-full max-w-md mx-4 text-center"
            style={{
              backgroundColor: "#F8FAFC",
              border: "1px solid #E5E7EB",
              boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
            }}
          >
            <CardContent className="p-8">
              <div className="mb-6">
                <div
                  className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: "#22C55E" }}
                >
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-2" style={{ color: "#1F2937" }}>
                  Congratulations!
                </h3>
                <p className="text-lg mb-4" style={{ color: "#6B7280" }}>
                  You've mastered all {flashcards.length} flashcards
                </p>
                <div className="flex items-center justify-center space-x-4 text-sm" style={{ color: "#6B7280" }}>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-1" style={{ color: "#22C55E" }} />
                    {correctCards.length} Correct
                  </div>
                  <div className="flex items-center">
                    <Trophy className="h-4 w-4 mr-1" style={{ color: "#F59E0B" }} />
                    {completedSets} Rounds
                  </div>
                </div>
              </div>

              <Button
                onClick={startReview}
                size="lg"
                className="w-full font-medium"
                style={{
                  backgroundColor: "#3EF2B5",
                  color: "#0F172A",
                  border: "none",
                }}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Review Again
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
