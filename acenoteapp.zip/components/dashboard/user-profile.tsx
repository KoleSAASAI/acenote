"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useAuth } from "@/lib/auth-context"
import { LogOut, Settings, User } from "lucide-react"
import { useRouter } from "next/navigation"

export function UserProfile() {
  const { user, signOut } = useAuth()
  const router = useRouter()

  const handleSignOut = async () => {
    try {
      // Sign out from Supabase
      await signOut()

      // Always redirect to logout page for consistent experience
      router.push("/logout")
    } catch (error) {
      console.error("Error during logout:", error)
      // Still redirect to logout page even if there's an error
      router.push("/logout")
    }
  }

  // Helper function to get user's display name
  const getUserDisplayName = () => {
    if (!user) return "User"

    // Try different sources for the name
    const fullName = user.user_metadata?.full_name || user.user_metadata?.name
    if (fullName) return fullName

    // For email users, try first_name + last_name
    const firstName = user.user_metadata?.first_name
    const lastName = user.user_metadata?.last_name
    if (firstName && lastName) return `${firstName} ${lastName}`
    if (firstName) return firstName

    // Fall back to email
    if (user.email) return user.email

    return "User"
  }

  // Helper function to get user's initials
  const getUserInitials = () => {
    const displayName = getUserDisplayName()

    // If it's an email, get initials from the part before @
    if (displayName.includes("@")) {
      const emailName = displayName.split("@")[0]
      return emailName.charAt(0).toUpperCase()
    }

    // For regular names, get first letter of each word
    const nameParts = displayName.split(" ").filter((part) => part.length > 0)
    if (nameParts.length >= 2) {
      return (nameParts[0].charAt(0) + nameParts[1].charAt(0)).toUpperCase()
    } else if (nameParts.length === 1) {
      return nameParts[0].charAt(0).toUpperCase()
    }

    return "U"
  }

  // Helper function to get avatar URL
  const getAvatarUrl = () => {
    return user?.user_metadata?.avatar_url || user?.user_metadata?.picture || ""
  }

  if (!user) return null

  const displayName = getUserDisplayName()
  const initials = getUserInitials()
  const avatarUrl = getAvatarUrl()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10">
            <AvatarImage src={avatarUrl || "/placeholder.svg"} alt={displayName} />
            <AvatarFallback className="bg-electric-cyan text-midnight-blue font-semibold">{initials}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{displayName}</p>
            <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => router.push("/dashboard/settings")}>
          <User className="mr-2 h-4 w-4" />
          <span>Profile</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => router.push("/dashboard/settings")}>
          <Settings className="mr-2 h-4 w-4" />
          <span>Settings</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleSignOut}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
