"use client"

import { useState, useEffect } from "react"
import { createPortal } from "react-dom"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, Check, Crown, Sparkles, AlertCircle } from "lucide-react"

interface UpgradeModalProps {
  isOpen: boolean
  onClose: () => void
  showLimitMessage?: boolean
}

export function UpgradeModal({ isOpen, onClose, showLimitMessage = false }: UpgradeModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<"annual" | "monthly">("annual")
  const [mounted, setMounted] = useState(false)
  const [loading, setLoading] = useState(false)

  const features = [
    "Unlimited PDF uploads, audio recordings, and YouTube videos",
    "Unlimited AI chat interactions with advanced reasoning",
    "Unlimited notes, flashcards, and quiz questions generation",
    "Priority processing and faster generation",
  ]

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  const handleUpgrade = async () => {
    setLoading(true)

    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan: selectedPlan === "annual" ? "yearly" : "monthly",
        }),
      })

      const data = await response.json()

      if (data.error) {
        console.error("Error creating checkout session:", data.error)
        alert("Failed to create checkout session. Please try again.")
        return
      }

      // Redirect to Stripe Checkout
      if (data.url) {
        window.location.href = data.url
      }
    } catch (error) {
      console.error("Error:", error)
      alert("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!mounted || !isOpen) return null

  const modalContent = (
    <div
      className="fixed inset-0 flex items-center justify-center p-4"
      style={{
        zIndex: 99999,
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      }}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70"
        style={{
          backdropFilter: "blur(8px)",
          WebkitBackdropFilter: "blur(8px)",
        }}
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-slate-900 border border-slate-700 rounded-2xl text-white shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 z-10 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>

        <div className="p-8">
          {showLimitMessage && (
            <div className="flex items-center justify-center gap-2 mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
              <AlertCircle className="h-5 w-5 text-red-400" />
              <span className="text-red-300 font-medium">Ran out of uploads</span>
            </div>
          )}

          <div className="text-center mb-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Crown className="h-8 w-8 text-[#3EF2B5]" />
              <h2 className="text-3xl font-bold">Upgrade to Ultimate!</h2>
            </div>
            <p className="text-slate-300 text-lg">Go unlimited — smarter notes, faster quizzes, better learning.</p>
          </div>

          <div className="space-y-4 mb-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <Check className="h-5 w-5 text-[#3EF2B5] mt-0.5 flex-shrink-0" />
                <span className="text-slate-200">{feature}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div
              className={`relative p-6 rounded-xl border-2 cursor-pointer transition-all ${
                selectedPlan === "annual"
                  ? "border-[#3EF2B5] bg-[#3EF2B5]/10"
                  : "border-slate-600 bg-slate-800 hover:border-slate-500"
              }`}
              onClick={() => setSelectedPlan("annual")}
            >
              <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-[#3EF2B5] text-slate-900 font-semibold">
                Save 50%
              </Badge>
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Annual</h3>
                <div className="text-3xl font-bold mb-1">$4.99</div>
                <div className="text-slate-400 text-sm">per month</div>
                <div className="text-slate-500 text-xs mt-1">billed yearly ($59.88)</div>
              </div>
            </div>

            <div
              className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
                selectedPlan === "monthly"
                  ? "border-[#3EF2B5] bg-[#3EF2B5]/10"
                  : "border-slate-600 bg-slate-800 hover:border-slate-500"
              }`}
              onClick={() => setSelectedPlan("monthly")}
            >
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Monthly</h3>
                <div className="text-3xl font-bold mb-1">$9.99</div>
                <div className="text-slate-400 text-sm">per month</div>
                <div className="text-slate-500 text-xs mt-1">billed monthly</div>
              </div>
            </div>
          </div>

          <Button
            className="w-full py-4 text-lg font-semibold bg-gradient-to-r from-[#3EF2B5] to-[#1DB58B] hover:from-[#1DB58B] hover:to-[#3EF2B5] text-slate-900 transition-all duration-300"
            onClick={handleUpgrade}
            disabled={loading}
          >
            <Sparkles className="h-5 w-5 mr-2" />
            {loading ? "Creating checkout..." : "Upgrade Now"}
            <Sparkles className="h-5 w-5 ml-2" />
          </Button>

          <p className="text-center text-slate-400 text-sm mt-6">
            Join 50,000+ students already boosting their grades with AceNote
          </p>
        </div>
      </div>
    </div>
  )

  return createPortal(modalContent, document.body)
}
