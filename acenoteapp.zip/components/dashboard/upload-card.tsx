"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, FileText, X } from "lucide-react"
import { UpgradeModal } from "./upgrade-modal"

interface UploadCardProps {
  onFileUpload: (fileName: string) => void
}

export function UploadCard({ onFileUpload }: UploadCardProps) {
  const [isDragOver, setIsDragOver] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Update the checkUploadLimit function to simulate a free user who has reached their limit
  const checkUploadLimit = async () => {
    // This would normally check the user's subscription and usage from your backend
    // For demo purposes, we'll simulate a free user who has reached their limit
    const userPlan = "free" // This would come from your auth context
    const uploadsThisMonth = 1 // This would come from your backend

    if (userPlan === "free" && uploadsThisMonth >= 1) {
      return false // User has reached limit - always show upgrade modal
    }
    return true // User can upload
  }

  // Update the handleFileSelect function to always check limits
  const handleFileSelect = async (file: File) => {
    const canUpload = await checkUploadLimit()

    if (!canUpload) {
      setShowUpgradeModal(true)
      return // Stop the upload process and show upgrade modal
    }

    // Check file size limit for free users (50MB)
    const maxSize = 50 * 1024 * 1024 // 50MB in bytes
    if (file.size > maxSize) {
      setShowUpgradeModal(true)
      return // Stop the upload process and show upgrade modal
    }

    setSelectedFile(file)
    onFileUpload(file.name)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  return (
    <>
      <div
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
          isDragOver ? "border-blue-400 bg-blue-500/10" : "border-slate-600 hover:border-slate-500 bg-slate-800/30"
        }`}
        onDragOver={(e) => {
          e.preventDefault()
          setIsDragOver(true)
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg"
          onChange={handleFileInputChange}
          className="hidden"
        />

        {selectedFile ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3">
              <FileText className="h-8 w-8 text-blue-400" />
              <span className="text-white font-medium">{selectedFile.name}</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedFile(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <Upload className="h-12 w-12 text-slate-400" />
            </div>
            <div>
              <p className="text-white font-medium mb-2">Drop your files here</p>
              <p className="text-slate-400 text-sm mb-4">or</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Browse Files
              </Button>
            </div>
            <p className="text-xs text-slate-500">Supports PDF, DOC, DOCX, TXT, PNG, JPG (Max 50MB)</p>
          </div>
        )}
      </div>

      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} showLimitMessage={true} />
    </>
  )
}
