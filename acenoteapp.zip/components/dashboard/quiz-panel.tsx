"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, RotateCcw } from "lucide-react"

const quizQuestions = [
  {
    question: "What is the primary function of chlorophyll in photosynthesis?",
    options: ["To absorb light energy", "To produce oxygen", "To store glucose", "To transport water"],
    correctAnswer: 0,
    explanation:
      "Chlorophyll's main function is to absorb light energy, which is then converted into chemical energy during photosynthesis.",
  },
  {
    question: "Where do the light reactions of photosynthesis occur?",
    options: ["In the stroma", "In the thylakoid membranes", "In the nucleus", "In the cytoplasm"],
    correctAnswer: 1,
    explanation: "Light reactions occur in the thylakoid membranes where chlorophyll captures light energy.",
  },
  {
    question: "What are the products of photosynthesis?",
    options: ["Carbon dioxide and water", "Glucose and carbon dioxide", "Glucose and oxygen", "Water and oxygen"],
    correctAnswer: 2,
    explanation: "Photosynthesis produces glucose (C₆H₁₂O₆) and oxygen (O₂) as its main products.",
  },
]

export function QuizPanel() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<(number | null)[]>(new Array(quizQuestions.length).fill(null))

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
  }

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return

    const newAnswers = [...answers]
    newAnswers[currentQuestion] = selectedAnswer
    setAnswers(newAnswers)

    if (selectedAnswer === quizQuestions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    setShowResult(true)
  }

  const handleNextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowResult(false)
    } else {
      // Move to completion screen
      setCurrentQuestion(quizQuestions.length)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setAnswers(new Array(quizQuestions.length).fill(null))
  }

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100
  const isQuizComplete = currentQuestion >= quizQuestions.length

  if (isQuizComplete) {
    return (
      <div className="space-y-6">
        <Card className="bg-card-custom border-subtle" style={{ backgroundColor: "#273349", borderColor: "#94A3B8" }}>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-light" style={{ color: "#F8FAFC" }}>
              Quiz Complete!
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="text-6xl font-bold" style={{ color: "#3EF2B5" }}>
              {Math.round((score / quizQuestions.length) * 100)}%
            </div>
            <div>
              <p className="text-xl mb-2" style={{ color: "#F8FAFC" }}>
                You scored {score} out of {quizQuestions.length}
              </p>
              <Badge
                variant={
                  score >= quizQuestions.length * 0.8
                    ? "default"
                    : score >= quizQuestions.length * 0.6
                      ? "secondary"
                      : "destructive"
                }
                className="text-lg px-4 py-2"
              >
                {score >= quizQuestions.length * 0.8
                  ? "Excellent!"
                  : score >= quizQuestions.length * 0.6
                    ? "Good Job!"
                    : "Keep Studying!"}
              </Badge>
            </div>
            <Button onClick={resetQuiz} size="lg">
              <RotateCcw className="h-4 w-4 mr-2" />
              Retake Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-light" style={{ color: "#F8FAFC" }}>
            Practice Quiz
          </h2>
          <p className="text-gray-300" style={{ color: "#94A3B8" }}>
            Question {currentQuestion + 1} of {quizQuestions.length}
          </p>
        </div>
        <Badge variant="secondary" style={{ backgroundColor: "#3EF2B5", color: "#0F172A" }}>
          Score: {score}/{quizQuestions.length}
        </Badge>
      </div>

      {/* Progress */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-light" style={{ color: "#F8FAFC" }}>
            Progress
          </span>
          <span className="text-light" style={{ color: "#F8FAFC" }}>
            {Math.round(progress)}%
          </span>
        </div>
        <div className="w-full bg-midnight-blue rounded-full h-2" style={{ backgroundColor: "#1E293B" }}>
          <div
            className="h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%`, backgroundColor: "#3EF2B5" }}
          />
        </div>
      </div>

      {/* Question */}
      <Card className="bg-card-custom border-subtle" style={{ backgroundColor: "#273349", borderColor: "#94A3B8" }}>
        <CardHeader>
          <CardTitle className="text-lg text-light" style={{ color: "#F8FAFC" }}>
            {quizQuestions[currentQuestion].question}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {quizQuestions[currentQuestion].options.map((option, index) => (
            <Button
              key={index}
              variant="outline"
              className="w-full justify-start text-left h-auto p-4 transition-all duration-200"
              style={{
                backgroundColor: showResult
                  ? index === quizQuestions[currentQuestion].correctAnswer
                    ? "#3EF2B5"
                    : selectedAnswer === index && index !== quizQuestions[currentQuestion].correctAnswer
                      ? "#EF4444"
                      : "#1E293B"
                  : selectedAnswer === index
                    ? "#3EF2B5"
                    : "#1E293B",
                borderColor: showResult
                  ? index === quizQuestions[currentQuestion].correctAnswer
                    ? "#3EF2B5"
                    : selectedAnswer === index && index !== quizQuestions[currentQuestion].correctAnswer
                      ? "#EF4444"
                      : "#374151"
                  : selectedAnswer === index
                    ? "#3EF2B5"
                    : "#374151",
                color: showResult
                  ? index === quizQuestions[currentQuestion].correctAnswer
                    ? "#0F172A"
                    : selectedAnswer === index && index !== quizQuestions[currentQuestion].correctAnswer
                      ? "#FFFFFF"
                      : "#F8FAFC"
                  : selectedAnswer === index
                    ? "#0F172A"
                    : "#F8FAFC",
              }}
              onMouseEnter={(e) => {
                if (!showResult && selectedAnswer !== index) {
                  e.currentTarget.style.backgroundColor = "#273349"
                  e.currentTarget.style.borderColor = "#3EF2B5"
                  e.currentTarget.style.color = "#F8FAFC"
                }
              }}
              onMouseLeave={(e) => {
                if (!showResult && selectedAnswer !== index) {
                  e.currentTarget.style.backgroundColor = "#1E293B"
                  e.currentTarget.style.borderColor = "#374151"
                  e.currentTarget.style.color = "#F8FAFC"
                }
              }}
              onClick={() => !showResult && handleAnswerSelect(index)}
              disabled={showResult}
            >
              <div className="flex items-center space-x-3 w-full">
                <div
                  className="flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center text-sm font-medium"
                  style={{
                    borderColor:
                      showResult && index === quizQuestions[currentQuestion].correctAnswer
                        ? "#0F172A"
                        : selectedAnswer === index
                          ? showResult && index !== quizQuestions[currentQuestion].correctAnswer
                            ? "#FFFFFF"
                            : "#0F172A"
                          : "#F8FAFC",
                    color:
                      showResult && index === quizQuestions[currentQuestion].correctAnswer
                        ? "#0F172A"
                        : selectedAnswer === index
                          ? showResult && index !== quizQuestions[currentQuestion].correctAnswer
                            ? "#FFFFFF"
                            : "#0F172A"
                          : "#F8FAFC",
                  }}
                >
                  {String.fromCharCode(65 + index)}
                </div>
                <span className="flex-1">{option}</span>
                {showResult && index === quizQuestions[currentQuestion].correctAnswer && (
                  <CheckCircle className="h-5 w-5 text-green-600 ml-auto" />
                )}
                {showResult && selectedAnswer === index && index !== quizQuestions[currentQuestion].correctAnswer && (
                  <XCircle className="h-5 w-5 text-red-600 ml-auto" />
                )}
              </div>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Explanation */}
      {showResult && (
        <Card className="bg-card-custom border-subtle" style={{ backgroundColor: "#273349", borderColor: "#94A3B8" }}>
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
              <div>
                <h4 className="font-medium mb-1 text-light" style={{ color: "#F8FAFC" }}>
                  Explanation
                </h4>
                <p className="text-gray-700 text-light" style={{ color: "#F8FAFC" }}>
                  {quizQuestions[currentQuestion].explanation}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex justify-center space-x-4">
        {!showResult ? (
          <Button
            onClick={handleSubmitAnswer}
            disabled={selectedAnswer === null}
            size="lg"
            className="hover:shadow-lg hover:shadow-[#1DB58B]/30 disabled:opacity-50"
            style={{ backgroundColor: "#3EF2B5", color: "#1E293B" }}
          >
            Submit Answer
          </Button>
        ) : (
          <Button
            onClick={handleNextQuestion}
            size="lg"
            className="hover:shadow-lg hover:shadow-[#1DB58B]/30"
            style={{ backgroundColor: "#3EF2B5", color: "#1E293B" }}
          >
            {currentQuestion < quizQuestions.length - 1 ? "Next Question" : "Finish Quiz"}
          </Button>
        )}
      </div>
    </div>
  )
}
