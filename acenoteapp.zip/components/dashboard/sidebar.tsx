"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { GraduationCap, Home, Upload, Settings, Sparkles } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { UpgradeModal } from "./upgrade-modal"
import { useAuth } from "@/lib/auth-context"
import { getUserSubscription } from "@/lib/subscription"
import { useEffect } from "react"

const sidebarItems = [
  { icon: Home, label: "Dashboard", href: "/dashboard" },
  { icon: Upload, label: "Upload", href: "/dashboard/upload" },
  { icon: Settings, label: "Settings", href: "/dashboard/settings" },
]

export function Sidebar() {
  const pathname = usePathname()
  const { user } = useAuth()
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false)
  const [isPremium, setIsPremium] = useState(false)

  useEffect(() => {
    const checkSubscription = async () => {
      if (user) {
        try {
          const subscription = await getUserSubscription(user.id)
          setIsPremium(subscription?.plan?.name === "Ultimate Plan")
        } catch (error) {
          console.error("Error checking subscription:", error)
          setIsPremium(false)
        }
      }
    }

    checkSubscription()
  }, [user])

  return (
    <>
      <div className="w-64 bg-midnight-blue h-screen sticky top-0">
        <div className="p-6">
          <div className="flex items-center space-x-2">
            <GraduationCap className="h-8 w-8 text-electric-cyan" style={{ color: "#3EF2B5" }} />
            <span className="text-xl font-bold text-light" style={{ color: "#F8FAFC" }}>
              acenoteAI
            </span>
          </div>
        </div>

        <nav className="px-4 space-y-2">
          {sidebarItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start text-light hover:bg-card-custom transition-colors",
                    isActive && "bg-electric-cyan text-midnight-blue hover:bg-accent-hover",
                  )}
                  style={
                    isActive
                      ? {
                          backgroundColor: "#3EF2B5",
                          color: "#1E293B",
                        }
                      : {
                          color: "#F8FAFC",
                        }
                  }
                >
                  <item.icon className="mr-3 h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            )
          })}

          {/* Upgrade Button - Only show for free users */}
          {!isPremium && (
            <div className="pt-4">
              <Button
                onClick={() => setIsUpgradeModalOpen(true)}
                className="w-full justify-start bg-gradient-to-r from-[#3EF2B5] to-[#1DB58B] hover:from-[#1DB58B] hover:to-[#3EF2B5] text-slate-900 font-semibold transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <Sparkles className="mr-3 h-4 w-4" />
                Upgrade to Ultimate
              </Button>
            </div>
          )}
        </nav>
      </div>

      <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setIsUpgradeModalOpen(false)} />
    </>
  )
}
