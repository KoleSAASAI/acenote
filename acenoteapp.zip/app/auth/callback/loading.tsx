export default function Loading() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-800/50 border border-slate-600 rounded-3xl p-8 space-y-6 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400 mx-auto"></div>
          <div className="space-y-2">
            <h2 className="text-xl font-bold text-white">Loading...</h2>
            <p className="text-slate-300">Please wait while we process your request.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
