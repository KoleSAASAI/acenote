"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { CheckCircle, AlertCircle } from "lucide-react"

export default function AuthCallback() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [message, setMessage] = useState("")

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const code = searchParams.get("code")
        const error = searchParams.get("error")
        const errorDescription = searchParams.get("error_description")

        if (error) {
          setStatus("error")
          setMessage(errorDescription || "Authentication failed")
          setTimeout(() => router.push("/signin"), 3000)
          return
        }

        if (code) {
          const { data, error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)

          if (exchangeError) {
            console.error("Error exchanging code for session:", exchangeError)
            setStatus("error")
            setMessage("Failed to complete authentication")
            setTimeout(() => router.push("/signin"), 3000)
            return
          }

          if (data.session) {
            setStatus("success")
            setMessage("Successfully signed in! Redirecting...")
            setTimeout(() => router.push("/dashboard"), 1500)
          }
        } else {
          // Handle direct session from URL fragments (for email confirmation)
          const { data, error: sessionError } = await supabase.auth.getSession()

          if (sessionError) {
            setStatus("error")
            setMessage("Authentication failed")
            setTimeout(() => router.push("/signin"), 3000)
          } else if (data.session) {
            setStatus("success")
            setMessage("Email confirmed! Redirecting...")
            setTimeout(() => router.push("/dashboard"), 1500)
          } else {
            setStatus("error")
            setMessage("No valid session found")
            setTimeout(() => router.push("/signin"), 3000)
          }
        }
      } catch (error) {
        console.error("Auth callback error:", error)
        setStatus("error")
        setMessage("An unexpected error occurred")
        setTimeout(() => router.push("/signin"), 3000)
      }
    }

    handleAuthCallback()
  }, [router, searchParams])

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-800/50 border border-slate-600 rounded-3xl p-8 space-y-6 text-center">
          {status === "loading" && (
            <>
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400 mx-auto"></div>
              <div className="space-y-2">
                <h2 className="text-xl font-bold text-white">Completing sign in...</h2>
                <p className="text-slate-300">Please wait while we verify your account.</p>
              </div>
            </>
          )}

          {status === "success" && (
            <>
              <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-emerald-400" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-bold text-white">Success!</h2>
                <p className="text-slate-300">{message}</p>
              </div>
            </>
          )}

          {status === "error" && (
            <>
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8 text-red-400" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-bold text-white">Authentication Failed</h2>
                <p className="text-slate-300">{message}</p>
                <p className="text-slate-400 text-sm">Redirecting to sign in...</p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
