"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

export default function LogoutPage() {
  const router = useRouter()
  const { signOut } = useAuth()

  useEffect(() => {
    const performLogout = async () => {
      try {
        // Sign out from Supabase
        await signOut()

        // Wait 2 seconds then redirect to home
        setTimeout(() => {
          router.push("/")
        }, 2000)
      } catch (error) {
        console.error("Error during logout:", error)
        // Still redirect even if there's an error
        setTimeout(() => {
          router.push("/")
        }, 2000)
      }
    }

    performLogout()
  }, [signOut, router])

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#0F172A" }}>
      <div className="text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[#3EF2B5] mx-auto mb-4"></div>
        <h1 className="text-2xl font-semibold text-white mb-2">Logging out...</h1>
        <p className="text-slate-300">Please wait while we sign you out securely.</p>
      </div>
    </div>
  )
}
