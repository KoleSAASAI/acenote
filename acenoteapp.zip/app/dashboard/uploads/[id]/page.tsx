"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, FileText, Brain, BookOpen, MessageCircle, Settings } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { FlashcardView } from "@/components/dashboard/flashcard-view"
import { QuizPanel } from "@/components/dashboard/quiz-panel"
import { ChatPanel } from "@/components/dashboard/chat-panel"

interface UploadPageProps {
  params: {
    id: string
  }
}

export default function UploadPage({ params }: UploadPageProps) {
  const [activeTab, setActiveTab] = useState("notes")

  // Scroll to top when page loads
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  // Mock data - in real app, this would come from API
  const uploadData = {
    id: params.id,
    name: "Biology Chapter 5 - Photosynthesis.pdf",
    uploadDate: "2024-03-15",
    type: "PDF",
    size: "2.4 MB",
    status: "processed",
  }

  const notes = [
    {
      title: "What is Photosynthesis?",
      content:
        "Photosynthesis is the process by which plants convert light energy into chemical energy. This process occurs in chloroplasts and involves two main stages: light reactions and the Calvin cycle.",
    },
    {
      title: "Key Components",
      content:
        "Chlorophyll absorbs light energy, primarily red and blue wavelengths. Water and carbon dioxide are the raw materials, while glucose and oxygen are the products.",
    },
    {
      title: "Chemical Equation",
      content: "The overall equation for photosynthesis is: 6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂",
    },
    {
      title: "Light Reactions",
      content:
        "Occur in the thylakoid membranes. Light energy is captured by chlorophyll and converted to chemical energy in the form of ATP and NADPH.",
    },
    {
      title: "Calvin Cycle",
      content:
        "Takes place in the stroma. Uses ATP and NADPH from light reactions to convert CO₂ into glucose through carbon fixation.",
    },
  ]

  const handleTabClick = (value: string) => {
    setActiveTab(value)
    // Remove focus from the clicked tab immediately
    setTimeout(() => {
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur()
      }
    }, 0)
  }

  return (
    <div className="space-y-6">
      {/* Header with Settings and Profile */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="text-light hover:bg-card-custom" style={{ color: "#F8FAFC" }}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-light" style={{ color: "#F8FAFC" }}>
              {uploadData.name}
            </h1>
          </div>
        </div>

        {/* Settings and Profile moved here */}
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="text-light hover:bg-card-custom" style={{ color: "#F8FAFC" }}>
            <Settings className="h-5 w-5" />
          </Button>
          <Avatar>
            <AvatarImage src="/placeholder-avatar.jpg" alt="User" />
            <AvatarFallback style={{ backgroundColor: "#3EF2B5", color: "#1E293B" }}>JD</AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Main Content - No Card wrapper, just direct content */}
      <div style={{ backgroundColor: "#0F172A" }}>
        <div className="pb-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList
              className="grid w-full grid-cols-4 h-12 mb-4"
              style={{
                backgroundColor: "transparent",
                border: "none",
                padding: 0,
              }}
            >
              <TabsTrigger
                value="notes"
                className="flex items-center gap-2 transition-colors"
                style={{
                  backgroundColor: activeTab === "notes" ? "#3EF2B5" : "transparent",
                  color: activeTab === "notes" ? "#0F172A" : "#F8FAFC",
                  border: "none",
                  outline: "none",
                }}
                tabIndex={-1}
                onClick={() => handleTabClick("notes")}
                onMouseEnter={(e) => {
                  if (activeTab !== "notes") {
                    e.currentTarget.style.backgroundColor = "#273349"
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== "notes") {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }
                }}
                onFocus={(e) => e.currentTarget.blur()}
              >
                <FileText className="h-4 w-4" />
                Notes
              </TabsTrigger>
              <TabsTrigger
                value="flashcards"
                className="flex items-center gap-2 transition-colors"
                style={{
                  backgroundColor: activeTab === "flashcards" ? "#3EF2B5" : "transparent",
                  color: activeTab === "flashcards" ? "#0F172A" : "#F8FAFC",
                  border: "none",
                  outline: "none",
                }}
                tabIndex={-1}
                onClick={() => handleTabClick("flashcards")}
                onMouseEnter={(e) => {
                  if (activeTab !== "flashcards") {
                    e.currentTarget.style.backgroundColor = "#273349"
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== "flashcards") {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }
                }}
                onFocus={(e) => e.currentTarget.blur()}
              >
                <Brain className="h-4 w-4" />
                Flashcards
              </TabsTrigger>
              <TabsTrigger
                value="quiz"
                className="flex items-center gap-2 transition-colors"
                style={{
                  backgroundColor: activeTab === "quiz" ? "#3EF2B5" : "transparent",
                  color: activeTab === "quiz" ? "#0F172A" : "#F8FAFC",
                  border: "none",
                  outline: "none",
                }}
                tabIndex={-1}
                onClick={() => handleTabClick("quiz")}
                onMouseEnter={(e) => {
                  if (activeTab !== "quiz") {
                    e.currentTarget.style.backgroundColor = "#273349"
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== "quiz") {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }
                }}
                onFocus={(e) => e.currentTarget.blur()}
              >
                <BookOpen className="h-4 w-4" />
                Quiz
              </TabsTrigger>
              <TabsTrigger
                value="chat"
                className="flex items-center gap-2 transition-colors"
                style={{
                  backgroundColor: activeTab === "chat" ? "#3EF2B5" : "transparent",
                  color: activeTab === "chat" ? "#0F172A" : "#F8FAFC",
                  border: "none",
                  outline: "none",
                }}
                tabIndex={-1}
                onClick={() => handleTabClick("chat")}
                onMouseEnter={(e) => {
                  if (activeTab !== "chat") {
                    e.currentTarget.style.backgroundColor = "#273349"
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== "chat") {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }
                }}
                onFocus={(e) => e.currentTarget.blur()}
              >
                <MessageCircle className="h-4 w-4" />
                Chat
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="pt-2" style={{ backgroundColor: "#0F172A" }}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsContent value="notes" className="mt-0">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-light" style={{ color: "#F8FAFC" }}>
                    AI-Generated Notes
                  </h2>
                </div>
                <div className="space-y-1">
                  {notes.map((note, index) => (
                    <div
                      key={index}
                      className="group hover:bg-slate-800/50 rounded-lg p-4 transition-colors duration-200"
                    >
                      <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                        <span className="w-1 h-6 bg-blue-500 rounded-full mr-3"></span>
                        {note.title}
                      </h3>
                      <div className="ml-4 pl-3">
                        <p className="text-slate-300 leading-relaxed text-base">{note.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="flashcards" className="mt-0">
              <FlashcardView />
            </TabsContent>

            <TabsContent value="quiz" className="mt-0">
              <QuizPanel />
            </TabsContent>

            <TabsContent value="chat" className="mt-0">
              <ChatPanel />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
