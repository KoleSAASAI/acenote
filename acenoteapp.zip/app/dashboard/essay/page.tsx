"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PenTool, Lightbulb, RefreshCw, Copy, Loader2 } from "lucide-react"

export default function EssayPage() {
  const [essayText, setEssayText] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [activeTab, setActiveTab] = useState("outline")

  const generateOutline = () => {
    setIsGenerating(true)
    setTimeout(() => {
      setIsGenerating(false)
    }, 2000)
  }

  const rewriteDraft = () => {
    setIsGenerating(true)
    setTimeout(() => {
      setIsGenerating(false)
    }, 3000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Essay Helper</h1>
        <p className="text-gray-600 mt-2">Improve your writing with AI-powered suggestions and outlines</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PenTool className="h-5 w-5 mr-2" />
              Your Essay or Prompt
            </CardTitle>
            <CardDescription>Paste your essay draft or describe what you want to write about</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Paste your essay draft here, or describe your topic and requirements..."
              value={essayText}
              onChange={(e) => setEssayText(e.target.value)}
              className="min-h-[300px] mb-4"
            />
            <div className="flex gap-2">
              <Button onClick={generateOutline} disabled={!essayText || isGenerating}>
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Lightbulb className="h-4 w-4 mr-2" />
                )}
                Generate Outline
              </Button>
              <Button variant="outline" onClick={rewriteDraft} disabled={!essayText || isGenerating}>
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4 mr-2" />
                )}
                Rewrite Draft
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Output Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>AI Suggestions</CardTitle>
              <Badge variant="secondary">
                <Lightbulb className="h-3 w-3 mr-1" />
                AI Generated
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="outline">Outline</TabsTrigger>
                <TabsTrigger value="rewrite">Rewrite</TabsTrigger>
                <TabsTrigger value="feedback">Feedback</TabsTrigger>
              </TabsList>

              <TabsContent value="outline" className="mt-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">Essay Outline</h3>
                    <Button variant="ghost" size="sm">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="prose max-w-none text-sm">
                    <h4>I. Introduction</h4>
                    <ul>
                      <li>Hook: Start with a compelling statistic or question</li>
                      <li>Background information on the topic</li>
                      <li>Thesis statement: Clear position on the argument</li>
                    </ul>

                    <h4>II. Body Paragraph 1</h4>
                    <ul>
                      <li>Topic sentence introducing first main point</li>
                      <li>Evidence and examples supporting the point</li>
                      <li>Analysis connecting evidence to thesis</li>
                    </ul>

                    <h4>III. Body Paragraph 2</h4>
                    <ul>
                      <li>Topic sentence introducing second main point</li>
                      <li>Evidence and examples supporting the point</li>
                      <li>Analysis connecting evidence to thesis</li>
                    </ul>

                    <h4>IV. Counterargument</h4>
                    <ul>
                      <li>Acknowledge opposing viewpoint</li>
                      <li>Provide evidence for counterargument</li>
                      <li>Refute with stronger evidence</li>
                    </ul>

                    <h4>V. Conclusion</h4>
                    <ul>
                      <li>Restate thesis in new words</li>
                      <li>Summarize main points</li>
                      <li>Call to action or broader implications</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="rewrite" className="mt-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">Improved Version</h3>
                    <Button variant="ghost" size="sm">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm leading-relaxed">
                      Your rewritten essay will appear here after processing. The AI will improve:
                    </p>
                    <ul className="text-sm mt-2 space-y-1">
                      <li>• Sentence structure and flow</li>
                      <li>• Word choice and vocabulary</li>
                      <li>• Grammar and punctuation</li>
                      <li>• Clarity and coherence</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="feedback" className="mt-4">
                <div className="space-y-4">
                  <h3 className="font-medium">Writing Feedback</h3>
                  <div className="space-y-3">
                    <div className="border-l-4 border-green-500 pl-4">
                      <h4 className="font-medium text-green-800">Strengths</h4>
                      <p className="text-sm text-green-700">Clear thesis statement and good use of evidence</p>
                    </div>
                    <div className="border-l-4 border-yellow-500 pl-4">
                      <h4 className="font-medium text-yellow-800">Areas for Improvement</h4>
                      <p className="text-sm text-yellow-700">Consider adding more transitions between paragraphs</p>
                    </div>
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-medium text-blue-800">Suggestions</h4>
                      <p className="text-sm text-blue-700">Try varying sentence length for better flow</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Writing Tips */}
      <Card>
        <CardHeader>
          <CardTitle>Writing Tips</CardTitle>
          <CardDescription>Quick tips to improve your essay writing</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="font-medium text-blue-900 mb-2">Strong Thesis</h3>
              <p className="text-sm text-blue-700">Make your main argument clear and specific</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="font-medium text-green-900 mb-2">Evidence</h3>
              <p className="text-sm text-green-700">Support claims with credible sources and examples</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="font-medium text-purple-900 mb-2">Flow</h3>
              <p className="text-sm text-purple-700">Use transitions to connect ideas smoothly</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
