"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, FileText, Trash2, Youtube, Mic } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"

interface Upload {
  id: string
  file_name: string
  file_type: string
  upload_date: string
  flashcard_count?: number
  quiz_count?: number
}

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth()
  const router = useRouter()
  const [uploads, setUploads] = useState<Upload[]>([])
  const [dataLoading, setDataLoading] = useState(false)
  const [stats, setStats] = useState({
    totalUploads: 0,
    totalFlashcards: 0,
    totalQuizzes: 0,
  })

  // Debug logging
  console.log("📊 Dashboard State:", {
    hasUser: !!user,
    userEmail: user?.email,
    authLoading,
    dataLoading,
  })

  // Handle authentication redirect
  useEffect(() => {
    console.log("🔍 Dashboard auth check:", { authLoading, hasUser: !!user })

    if (!authLoading && !user) {
      console.log("🚫 No user found, redirecting to signin")
      router.push("/signin")
    }
  }, [user, authLoading, router])

  // Fetch user data when user is available
  useEffect(() => {
    if (user && !authLoading) {
      console.log("📥 User available, fetching uploads for:", user.email)
      fetchUserUploads()
    }
  }, [user, authLoading])

  // Auto-refresh when user navigates back to dashboard
  useEffect(() => {
    const handleFocus = () => {
      if (user && !authLoading && !dataLoading) {
        console.log("🔄 Window focused, refreshing dashboard data")
        fetchUserUploads()
      }
    }

    window.addEventListener("focus", handleFocus)
    return () => window.removeEventListener("focus", handleFocus)
  }, [user, authLoading, dataLoading])

  const fetchUserUploads = async () => {
    if (!user) {
      console.log("❌ No user available for fetching uploads")
      return
    }

    try {
      console.log("🔄 Starting to fetch uploads for user:", user.id)
      setDataLoading(true)

      // Fetch user uploads
      const { data: uploadsData, error: uploadsError } = await supabase
        .from("uploads")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "completed")
        .order("upload_date", { ascending: false })

      if (uploadsError) {
        console.error("❌ Error fetching uploads:", uploadsError)
        setUploads([])
        setStats({ totalUploads: 0, totalFlashcards: 0, totalQuizzes: 0 })
        return
      }

      console.log("✅ Fetched uploads:", uploadsData?.length || 0)

      // If no uploads, set empty state
      if (!uploadsData || uploadsData.length === 0) {
        setUploads([])
        setStats({ totalUploads: 0, totalFlashcards: 0, totalQuizzes: 0 })
        return
      }

      // Fetch flashcard and quiz counts for each upload
      const uploadsWithCounts = await Promise.all(
        uploadsData.map(async (upload) => {
          const [flashcardsResult, quizResult] = await Promise.all([
            supabase.from("flashcards").select("id", { count: "exact" }).eq("upload_id", upload.id),
            supabase.from("quiz_questions").select("id", { count: "exact" }).eq("upload_id", upload.id),
          ])

          return {
            ...upload,
            flashcard_count: flashcardsResult.count || 0,
            quiz_count: quizResult.count || 0,
          }
        }),
      )

      setUploads(uploadsWithCounts)

      // Calculate stats
      const totalFlashcards = uploadsWithCounts.reduce((sum, upload) => sum + (upload.flashcard_count || 0), 0)
      const totalQuizzes = uploadsWithCounts.reduce((sum, upload) => sum + (upload.quiz_count || 0), 0)

      setStats({
        totalUploads: uploadsWithCounts.length,
        totalFlashcards,
        totalQuizzes,
      })

      console.log("✅ Dashboard data loaded successfully", {
        uploads: uploadsWithCounts.length,
        flashcards: totalFlashcards,
        quizzes: totalQuizzes,
      })
    } catch (error) {
      console.error("❌ Error fetching uploads:", error)
      setUploads([])
      setStats({ totalUploads: 0, totalFlashcards: 0, totalQuizzes: 0 })
    } finally {
      setDataLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      // Delete from database
      const { error } = await supabase.from("uploads").delete().eq("id", id)
      if (error) throw error

      // Update local state
      const updatedUploads = uploads.filter((upload) => upload.id !== id)
      setUploads(updatedUploads)

      // Recalculate stats
      const totalFlashcards = updatedUploads.reduce((sum, upload) => sum + (upload.flashcard_count || 0), 0)
      const totalQuizzes = updatedUploads.reduce((sum, upload) => sum + (upload.quiz_count || 0), 0)

      setStats({
        totalUploads: updatedUploads.length,
        totalFlashcards,
        totalQuizzes,
      })

      console.log("✅ Upload deleted and stats updated")
    } catch (error) {
      console.error("Error deleting upload:", error)
      alert("Failed to delete upload")
    }
  }

  const getFileIcon = (type: string) => {
    if (type.includes("youtube") || type === "YOUTUBE") {
      return <Youtube className="h-5 w-5 text-red-400" />
    }
    if (type.includes("audio") || type === "AUDIO") {
      return <Mic className="h-5 w-5 text-green-400" />
    }
    return <FileText className="h-5 w-5 text-blue-400" />
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return `Created on ${date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })}`
  }

  const getFileTypeLabel = (fileName: string, fileType: string) => {
    if (fileName.includes("youtube") || fileType === "YOUTUBE") return "YOUTUBE"
    if (fileName.includes("audio") || fileType === "AUDIO") return "AUDIO"
    if (fileType.includes("pdf")) return "PDF"
    if (fileType.includes("doc")) return "DOCX"
    if (fileType.includes("text")) return "TXT"
    return "FILE"
  }

  // Show loading spinner while auth is loading
  if (authLoading) {
    console.log("⏳ Showing auth loading screen")
    return (
      <div className="container mx-auto pt-0 pb-4">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-300">Checking authentication...</p>
          </div>
        </div>
      </div>
    )
  }

  // Don't render anything if user is not authenticated (redirect will happen)
  if (!user) {
    console.log("🚫 No user, not rendering dashboard")
    return (
      <div className="container mx-auto pt-0 pb-4">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-300">Redirecting to sign in...</p>
          </div>
        </div>
      </div>
    )
  }

  console.log("✅ Rendering dashboard for user:", user.email)

  return (
    <div className="container mx-auto pt-0 pb-4">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">Dashboard</h1>
            <p className="text-slate-300">Access your previously uploaded study materials</p>
          </div>
          <Link href="/dashboard/upload">
            <Button>
              <FileText className="h-4 w-4 mr-2" />
              Upload New File
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-white">{stats.totalUploads}</div>
              <p className="text-sm text-slate-300">Total Uploads</p>
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-white">{stats.totalFlashcards}</div>
              <p className="text-sm text-slate-300">Flashcards Created</p>
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-white">{stats.totalQuizzes}</div>
              <p className="text-sm text-slate-300">Quizzes Available</p>
            </CardContent>
          </Card>
        </div>

        {/* Upload Cards */}
        {dataLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-300">Loading your uploads...</p>
          </div>
        ) : uploads.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {uploads.map((upload) => (
              <Card
                key={upload.id}
                className="bg-slate-800 border-slate-700 transition-transform duration-200 hover:scale-105"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      {getFileIcon(upload.file_type)}
                      <span className="px-2 py-1 text-xs font-medium text-white bg-transparent border border-slate-600 rounded">
                        {getFileTypeLabel(upload.file_name, upload.file_type)}
                      </span>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0 text-white hover:bg-slate-700">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                        <DropdownMenuItem
                          onClick={() => handleDelete(upload.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-slate-700"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <Link href={`/dashboard/uploads/${upload.id}`}>
                    <h3 className="font-semibold text-white mb-2 hover:text-slate-300 cursor-pointer line-clamp-2">
                      {upload.file_name}
                    </h3>
                  </Link>

                  <p className="text-sm text-slate-400 mb-4">{formatDate(upload.upload_date)}</p>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Flashcards:</span>
                      <span className="text-white">{upload.flashcard_count || 0}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Quizzes:</span>
                      <span className="text-white">{upload.quiz_count || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12 bg-slate-800 border-slate-700">
            <CardContent>
              <FileText className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No uploads yet</h3>
              <p className="text-slate-300 mb-6">Get started by uploading your first study material</p>
              <Link href="/dashboard/upload">
                <Button>
                  <FileText className="h-4 w-4 mr-2" />
                  Upload Your First File
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
