"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { BarChart3, TrendingUp, Target, Plus, BookOpen } from "lucide-react"

const grades = [
  { subject: "Biology", assignment: "Midterm Exam", grade: "A-", percentage: 92, weight: 25, date: "2024-03-15" },
  { subject: "Chemistry", assignment: "Lab Report #3", grade: "B+", percentage: 87, weight: 15, date: "2024-03-12" },
  { subject: "Physics", assignment: "Problem Set 5", grade: "A", percentage: 95, weight: 10, date: "2024-03-10" },
  { subject: "Mathematics", assignment: "Quiz 4", grade: "B", percentage: 83, weight: 8, date: "2024-03-08" },
  { subject: "English", assignment: "Essay #2", grade: "A-", percentage: 90, weight: 20, date: "2024-03-05" },
  { subject: "History", assignment: "Research Paper", grade: "B+", percentage: 88, weight: 30, date: "2024-03-01" },
]

const subjects = [
  { name: "Biology", current: "A-", predicted: "A-", credits: 4, gpa: 3.7 },
  { name: "Chemistry", current: "B+", predicted: "A-", credits: 4, gpa: 3.3 },
  { name: "Physics", current: "A", predicted: "A", credits: 3, gpa: 4.0 },
  { name: "Mathematics", current: "B+", predicted: "A-", credits: 4, gpa: 3.3 },
  { name: "English", current: "A-", predicted: "A-", credits: 3, gpa: 3.7 },
  { name: "History", current: "B+", predicted: "B+", credits: 3, gpa: 3.3 },
]

export default function GradesPage() {
  const currentGPA = 3.55
  const predictedGPA = 3.67

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Grade Tracker</h1>
        <p className="text-gray-600 mt-2">Monitor your academic progress and predict final grades</p>
      </div>

      {/* GPA Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
              Current GPA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600 mb-2">{currentGPA}</div>
            <p className="text-sm text-gray-600">Based on completed assignments</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
              Predicted GPA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600 mb-2">{predictedGPA}</div>
            <p className="text-sm text-gray-600">If current trends continue</p>
            <Badge variant="secondary" className="mt-2 bg-green-100 text-green-800">
              +0.12 improvement
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <Target className="h-5 w-5 mr-2 text-purple-600" />
              Goal Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600 mb-2">3.8</div>
            <p className="text-sm text-gray-600 mb-2">Target GPA</p>
            <Progress value={75} className="mb-2" />
            <p className="text-xs text-gray-500">75% to goal</p>
          </CardContent>
        </Card>
      </div>

      {/* Subject Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Subject Overview</CardTitle>
              <CardDescription>Current and predicted grades by subject</CardDescription>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Subject
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject</TableHead>
                <TableHead>Current Grade</TableHead>
                <TableHead>Predicted Grade</TableHead>
                <TableHead>Credits</TableHead>
                <TableHead>GPA Points</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {subjects.map((subject, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{subject.name}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{subject.current}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{subject.predicted}</Badge>
                  </TableCell>
                  <TableCell>{subject.credits}</TableCell>
                  <TableCell>{subject.gpa}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      <BookOpen className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Recent Assignments */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Assignments</CardTitle>
          <CardDescription>Your latest graded work</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject</TableHead>
                <TableHead>Assignment</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead>Percentage</TableHead>
                <TableHead>Weight</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {grades.map((grade, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{grade.subject}</TableCell>
                  <TableCell>{grade.assignment}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        grade.percentage >= 90 ? "default" : grade.percentage >= 80 ? "secondary" : "destructive"
                      }
                    >
                      {grade.grade}
                    </Badge>
                  </TableCell>
                  <TableCell>{grade.percentage}%</TableCell>
                  <TableCell>{grade.weight}%</TableCell>
                  <TableCell className="text-gray-500">{grade.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Grade Prediction Widget */}
      <Card>
        <CardHeader>
          <CardTitle>Grade Prediction</CardTitle>
          <CardDescription>See how different scores will affect your final grade</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                You're on track for a <span className="text-green-600">B+</span>
              </h3>
              <p className="text-gray-600 mb-4">Based on your current performance and remaining assignments</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-white p-3 rounded-lg">
                  <p className="font-medium">To get an A:</p>
                  <p className="text-gray-600">Score 92%+ on remaining work</p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <p className="font-medium">To maintain B+:</p>
                  <p className="text-gray-600">Score 85%+ on remaining work</p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <p className="font-medium">Risk of B:</p>
                  <p className="text-gray-600">Score below 80% on remaining work</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
