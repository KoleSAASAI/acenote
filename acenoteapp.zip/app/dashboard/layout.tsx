"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"

function UserProfileOnly() {
  const { user, signOut } = useAuth()
  const router = useRouter()

  const handleSignOut = async () => {
    await signOut()
    router.push("/logout")
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const getUserDisplayName = () => {
    if (!user) return "User"

    // Try different sources for the user's name
    const sources = [
      user.user_metadata?.full_name,
      user.user_metadata?.name,
      user.user_metadata?.first_name && user.user_metadata?.last_name
        ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}`
        : null,
      user.email,
    ]

    return sources.find((source) => source && source.trim()) || "User"
  }

  const getAvatarInitials = () => {
    const displayName = getUserDisplayName()
    if (displayName === user?.email) {
      // If using email, just use first letter
      return displayName.charAt(0).toUpperCase()
    }
    return getInitials(displayName)
  }

  if (!user) return null

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-8 w-8 p-0">
          <Avatar>
            <AvatarImage src={user?.user_metadata?.avatar_url || user?.user_metadata?.picture} alt="User" />
            <AvatarFallback style={{ backgroundColor: "#3EF2B5", color: "#1E293B" }}>
              {getAvatarInitials()}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem>{getUserDisplayName()}</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem>Settings</DropdownMenuItem>
        <DropdownMenuItem onClick={handleSignOut}>Sign out</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    console.log("🔒 Dashboard Layout - Auth Check:", {
      hasUser: !!user,
      loading,
      userEmail: user?.email,
    })

    // If not loading and no user, redirect to homepage
    if (!loading && !user) {
      console.log("❌ No authenticated user found, redirecting to homepage")
      router.replace("/")
      return
    }

    // If user is authenticated, log success
    if (!loading && user) {
      console.log("✅ User authenticated, allowing dashboard access:", user.email)
    }
  }, [user, loading, router])

  // Show loading while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Checking authentication...</p>
        </div>
      </div>
    )
  }

  // If no user after loading, show nothing (redirect will happen)
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Redirecting...</p>
        </div>
      </div>
    )
  }

  // Render dashboard for authenticated users
  return (
    <div className="min-h-screen bg-midnight-blue">
      <div className="flex">
        <Sidebar />
        <div className="flex-1 flex flex-col" style={{ backgroundColor: "#0F172A" }}>
          <div className="flex justify-end p-4">
            <UserProfileOnly />
          </div>
          <main className="flex-1 p-6 pt-0" style={{ backgroundColor: "#0F172A" }}>
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}
