"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { User, Bell, CreditCard, Save, LogOut, Lock, Mail, AlertCircle, Crown, Zap } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { getUserSubscription, getUserUsage, type UserSubscription, type UserUsage } from "@/lib/subscription"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function SettingsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [notifications, setNotifications] = useState({
    email: true,
  })
  const [profile, setProfile] = useState({
    firstName: "",
    lastName: "",
    email: "",
    university: "",
    major: "",
  })
  const [passwords, setPasswords] = useState({
    current: "",
    new: "",
    confirm: "",
  })
  const [subscription, setSubscription] = useState<UserSubscription | null>(null)
  const [usage, setUsage] = useState<UserUsage | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [changingPassword, setChangingPassword] = useState(false)
  const [changingEmail, setChangingEmail] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  // Check if user is using Google auth
  const isGoogleUser = user?.app_metadata?.provider === "google"
  const isEmailUser = user?.app_metadata?.provider === "email"

  useEffect(() => {
    if (user) {
      fetchProfile()
      fetchSubscriptionData()
    }
  }, [user])

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", user?.id).single()

      if (data) {
        const fullName = data.full_name || ""
        const nameParts = fullName.split(" ")

        setProfile({
          firstName: nameParts[0] || "",
          lastName: nameParts.slice(1).join(" ") || "",
          email: user?.email || "",
          university: data.university || "",
          major: data.major || "",
        })
      }
    } catch (error) {
      console.error("Error fetching profile:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchSubscriptionData = async () => {
    if (!user) return

    try {
      const [subscriptionData, usageData] = await Promise.all([getUserSubscription(user.id), getUserUsage(user.id)])

      setSubscription(subscriptionData)
      setUsage(usageData)
    } catch (error) {
      console.error("Error fetching subscription data:", error)
    }
  }

  const handleSaveProfile = async () => {
    setSaving(true)
    setMessage(null)

    try {
      const updates: any = {
        university: profile.university,
        major: profile.major,
        updated_at: new Date().toISOString(),
      }

      // For non-Google users, allow name updates
      if (!isGoogleUser) {
        updates.full_name = `${profile.firstName} ${profile.lastName}`.trim()
      }

      await supabase.from("profiles").update(updates).eq("id", user?.id)

      setMessage({ type: "success", text: "Profile updated successfully!" })
      // Scroll to top to show success message
      window.scrollTo({ top: 0, behavior: "smooth" })
    } catch (error) {
      console.error("Error updating profile:", error)
      setMessage({ type: "error", text: "Failed to update profile" })
    } finally {
      setSaving(false)
    }
  }

  const handleChangePassword = async () => {
    if (!passwords.current) {
      setMessage({ type: "error", text: "Please enter your current password" })
      return
    }

    if (passwords.new !== passwords.confirm) {
      setMessage({ type: "error", text: "New passwords do not match" })
      return
    }

    if (passwords.new.length < 6) {
      setMessage({ type: "error", text: "Password must be at least 6 characters long" })
      return
    }

    setChangingPassword(true)
    setMessage(null)

    try {
      // First verify current password by attempting to sign in
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user?.email || "",
        password: passwords.current,
      })

      if (signInError) {
        setMessage({ type: "error", text: "Current password is incorrect" })
        setChangingPassword(false)
        return
      }

      // If current password is correct, update to new password
      const { error } = await supabase.auth.updateUser({
        password: passwords.new,
      })

      if (error) {
        setMessage({ type: "error", text: error.message })
      } else {
        setMessage({ type: "success", text: "Password updated successfully!" })
        setPasswords({ current: "", new: "", confirm: "" })
        // Scroll to top to show success message
        window.scrollTo({ top: 0, behavior: "smooth" })
      }
    } catch (error: any) {
      setMessage({ type: "error", text: error.message || "Failed to update password" })
    } finally {
      setChangingPassword(false)
    }
  }

  const handleChangeEmail = async () => {
    if (!profile.email || profile.email === user?.email) {
      setMessage({ type: "error", text: "Please enter a new email address" })
      return
    }

    setChangingEmail(true)
    setMessage(null)

    try {
      // Store the email change request in our database first
      const { error: dbError } = await supabase.from("email_change_requests").insert({
        user_id: user?.id,
        old_email: user?.email,
        new_email: profile.email,
        created_at: new Date().toISOString(),
        status: "pending",
      })

      if (dbError) {
        console.error("Database error:", dbError)
        // If the table doesn't exist, fall back to Supabase's default behavior
        const { error } = await supabase.auth.updateUser({
          email: profile.email,
        })

        if (error) {
          setMessage({ type: "error", text: error.message })
        } else {
          setMessage({
            type: "success",
            text: "Email change request sent. Please check your current email address for confirmation.",
          })
        }
      } else {
        // Send custom email to old address only
        // For now, we'll use Supabase's built-in method but inform user about both emails
        const { error } = await supabase.auth.updateUser({
          email: profile.email,
        })

        if (error) {
          setMessage({ type: "error", text: error.message })
        } else {
          setMessage({
            type: "success",
            text: "Email change confirmation sent to your current email address. Note: You may also receive a notification at the new email address - this is normal for security purposes.",
          })
          // Scroll to top to show success message
          window.scrollTo({ top: 0, behavior: "smooth" })
        }
      }
    } catch (error: any) {
      setMessage({ type: "error", text: error.message || "Failed to update email" })
    } finally {
      setChangingEmail(false)
    }
  }

  const handleLogout = async () => {
    router.push("/logout")
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  const plan = subscription?.plan
  const isPremium = plan?.name === "Ultimate Plan"

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-slate-300 mt-2">Manage your account preferences and application settings</p>
      </div>

      {message && (
        <Alert className={`${message.type === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}`}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className={message.type === "error" ? "text-red-700" : "text-green-700"}>
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800 border-slate-700">
          <TabsTrigger
            value="profile"
            className="flex items-center gap-2 text-slate-300 data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A]"
          >
            <User className="h-4 w-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger
            value="notifications"
            className="flex items-center gap-2 text-slate-300 data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A]"
          >
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger
            value="billing"
            className="flex items-center gap-2 text-slate-300 data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A]"
          >
            <CreditCard className="h-4 w-4" />
            Billing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Profile Information</CardTitle>
              <CardDescription className="text-slate-300">
                {isGoogleUser
                  ? "Your Google account information and editable profile settings"
                  : "Your account information and profile settings"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={user?.user_metadata?.avatar_url || user?.user_metadata?.picture} alt="Profile" />
                    <AvatarFallback className="text-lg" style={{ backgroundColor: "#3EF2B5", color: "#1E293B" }}>
                      {getInitials(
                        `${profile.firstName} ${profile.lastName}` ||
                          user?.user_metadata?.full_name ||
                          user?.user_metadata?.name ||
                          user?.email ||
                          "U",
                      )}
                    </AvatarFallback>
                  </Avatar>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName" className="text-white">
                      First Name
                    </Label>
                    <Input
                      id="firstName"
                      value={profile.firstName}
                      onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
                      disabled={isGoogleUser}
                      className={`${
                        isGoogleUser
                          ? "bg-slate-700 border-slate-600 text-slate-400 cursor-not-allowed"
                          : "bg-slate-700 border-slate-600 text-white"
                      }`}
                    />
                    {isGoogleUser && <p className="text-xs text-slate-500">Managed by Google</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName" className="text-white">
                      Last Name
                    </Label>
                    <Input
                      id="lastName"
                      value={profile.lastName}
                      onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
                      disabled={isGoogleUser}
                      className={`${
                        isGoogleUser
                          ? "bg-slate-700 border-slate-600 text-slate-400 cursor-not-allowed"
                          : "bg-slate-700 border-slate-600 text-white"
                      }`}
                    />
                    {isGoogleUser && <p className="text-xs text-slate-500">Managed by Google</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email Address
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                      disabled={isGoogleUser}
                      className={`${
                        isGoogleUser
                          ? "bg-slate-700 border-slate-600 text-slate-400 cursor-not-allowed"
                          : "bg-slate-700 border-slate-600 text-white"
                      }`}
                    />
                    {!isGoogleUser && (
                      <Button
                        onClick={handleChangeEmail}
                        disabled={changingEmail || profile.email === user?.email}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Mail className="h-4 w-4 mr-2" />
                        {changingEmail ? "Sending..." : "Update"}
                      </Button>
                    )}
                  </div>
                  {isGoogleUser && <p className="text-xs text-slate-500">Managed by Google</p>}
                  {!isGoogleUser && (
                    <p className="text-xs text-slate-400">
                      Note: Due to Supabase security policies, confirmation emails are sent to both your current and new
                      email addresses. Only confirm the change if you initiated it.
                    </p>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-600 pt-6 space-y-4">
                <h3 className="text-lg font-medium text-white">Academic Information</h3>

                <div className="space-y-2">
                  <Label htmlFor="university" className="text-white">
                    University/School
                  </Label>
                  <Input
                    id="university"
                    value={profile.university}
                    onChange={(e) => setProfile({ ...profile, university: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter your university or school"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="major" className="text-white">
                    Major/Field of Study
                  </Label>
                  <Input
                    id="major"
                    value={profile.major}
                    onChange={(e) => setProfile({ ...profile, major: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter your major or field of study"
                  />
                </div>

                <div className="flex justify-between items-center pt-4">
                  <Button
                    onClick={handleSaveProfile}
                    disabled={saving}
                    style={{ backgroundColor: "#3EF2B5", color: "#0F172A" }}
                    className="hover:bg-[#1DB58B]"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? "Saving..." : "Save Info"}
                  </Button>

                  <Button onClick={handleLogout} className="bg-red-600 hover:bg-red-700 text-white">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </div>

              {/* Password Change Section - Only for email users */}
              {isEmailUser && (
                <div className="border-t border-slate-600 pt-6 space-y-4">
                  <h3 className="text-lg font-medium text-white flex items-center gap-2">
                    <Lock className="h-5 w-5" />
                    Change Password
                  </h3>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword" className="text-white">
                        Current Password
                      </Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={passwords.current}
                        onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Enter current password"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPassword" className="text-white">
                        New Password
                      </Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwords.new}
                        onChange={(e) => setPasswords({ ...passwords, new: e.target.value })}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Enter new password"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-white">
                        Confirm New Password
                      </Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwords.confirm}
                        onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Confirm new password"
                      />
                    </div>

                    <Button
                      onClick={handleChangePassword}
                      disabled={changingPassword || !passwords.current || !passwords.new || !passwords.confirm}
                      className="bg-orange-600 hover:bg-orange-700 text-white"
                    >
                      <Lock className="h-4 w-4 mr-2" />
                      {changingPassword ? "Updating..." : "Update Password"}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Notification Preferences</CardTitle>
              <CardDescription className="text-slate-300">
                Choose how you want to be notified about your study progress and updates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-white">Email Notifications</Label>
                  <p className="text-sm text-slate-400">Receive updates via email</p>
                </div>
                <Switch
                  checked={notifications.email}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                {isPremium ? <Crown className="h-5 w-5 text-yellow-400" /> : <Zap className="h-5 w-5 text-blue-400" />}
                Current Plan
              </CardTitle>
              <CardDescription className="text-slate-300">
                Manage your subscription and billing information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    {isPremium ? "Ultimate Plan" : "Free Plan"}
                    {isPremium && <Crown className="h-4 w-4 text-yellow-400" />}
                  </h3>
                  <p className="text-slate-300">
                    {isPremium ? "Unlimited uploads and AI features" : "Limited uploads and AI features"}
                  </p>
                </div>
                <Badge className={isPremium ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"}>
                  Active
                </Badge>
              </div>

              {isPremium && (
                <Button className="w-full hover:bg-[#1DB58B]" style={{ backgroundColor: "#3EF2B5", color: "#0F172A" }}>
                  Open Billing Portal
                </Button>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
