"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FileText, Youtube, Mic, Upload, Sparkles } from "lucide-react"
import { UploadCard } from "@/components/dashboard/upload-card"
import { AudioUploadCard } from "@/components/dashboard/audio-upload-card"
import { UpgradeModal } from "@/components/dashboard/upgrade-modal"
import { useRouter } from "next/navigation"

export default function UploadPage() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<string | null>(null)
  const [youtubeUrl, setYoutubeUrl] = useState("")
  const [isProcessingYoutube, setIsProcessingYoutube] = useState(false)
  const [isProcessingAudio, setIsProcessingAudio] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)
  const [progress, setProgress] = useState(0)
  const [processingType, setProcessingType] = useState<"document" | "youtube" | "audio" | null>(null)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const router = useRouter()

  // Trigger animations after component mounts
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 50) // Small delay to ensure DOM is ready
    return () => clearTimeout(timer)
  }, [])

  // Progress animation effect
  useEffect(() => {
    if (isProcessing || isProcessingYoutube || isProcessingAudio) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            // Redirect after completion
            setTimeout(() => {
              if (processingType === "document" && uploadedFile) {
                router.push(`/dashboard/uploads/${encodeURIComponent(uploadedFile)}`)
              } else if (processingType === "youtube") {
                router.push(`/dashboard/uploads/youtube-${Date.now()}`)
              } else if (processingType === "audio") {
                router.push(`/dashboard/uploads/audio-${Date.now()}`)
              }
            }, 500)
            return 100
          }
          return prev + Math.random() * 15 + 5 // Random increment between 5-20
        })
      }, 200)
      return () => clearInterval(interval)
    }
  }, [isProcessing, isProcessingYoutube, isProcessingAudio, processingType, uploadedFile, router])

  // Mock function to check if user has reached upload limit
  const checkUploadLimit = async () => {
    const userPlan = "free" // This would come from your auth context
    const uploadsThisMonth = 1 // This would come from your backend

    if (userPlan === "free" && uploadsThisMonth >= 1) {
      return false // User has reached limit
    }
    return true // User can upload
  }

  const handleFileUpload = (fileName: string) => {
    setUploadedFile(fileName)
    setIsProcessing(true)
    setProcessingType("document")
    setProgress(0)
  }

  // Update the handleYoutubeSubmit function to always check limits
  const handleYoutubeSubmit = async () => {
    if (!youtubeUrl.trim()) return

    const canUpload = await checkUploadLimit()
    if (!canUpload) {
      setShowUpgradeModal(true)
      return // Stop the upload process and show upgrade modal
    }

    setIsProcessingYoutube(true)
    setProcessingType("youtube")
    setProgress(0)
  }

  const handleAudioUpload = (fileName: string) => {
    setIsProcessingAudio(true)
    setProcessingType("audio")
    setProgress(0)
  }

  const isValidYoutubeUrl = (url: string) => {
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/
    return youtubeRegex.test(url)
  }

  return (
    <div className="min-h-screen bg-slate-900 p-6 pt-2">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div
          className={`text-center mb-12 transition-all duration-1000 ${
            isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 backdrop-blur-sm border border-emerald-500/20 rounded-full px-4 py-2 mb-6">
            <Sparkles className="h-4 w-4 text-emerald-400" />
            <span className="text-sm font-medium text-emerald-300">AI-Powered Study Tools</span>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-white via-emerald-100 to-blue-100 bg-clip-text text-transparent mb-6">
            Upload Study Materials
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Smarter Studying Starts with One Upload
          </p>
        </div>

        {!uploadedFile && !isProcessingYoutube && !isProcessingAudio ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Document Upload Section */}
            <div
              className={`group transition-all duration-1000 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: isLoaded ? "200ms" : "0ms" }}
            >
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-500/10 via-slate-800/50 to-slate-900/80 backdrop-blur-sm border border-blue-500/20 p-8 transition-all duration-200 hover:scale-[1.02] hover:shadow-2xl hover:shadow-blue-500/10 hover:border-blue-400/40 h-full flex flex-col">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />

                <div className="relative z-10 flex flex-col h-full">
                  <div className="flex items-center justify-center mb-6">
                    <div className="relative">
                      <div className="absolute inset-0 bg-blue-500/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-200" />
                      <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 p-4 rounded-2xl">
                        <Upload className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-white mb-2">Document Upload</h3>
                    <p className="text-slate-300">PDFs, documents, etc!</p>
                  </div>

                  <div className="flex-grow">
                    <UploadCard onFileUpload={handleFileUpload} />
                  </div>

                  <div className="mt-6">
                    <p className="text-sm text-slate-400 text-center">
                      Turn your class notes into flashcards and quizzes — instantly.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* YouTube Section */}
            <div
              className={`group transition-all duration-1000 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: isLoaded ? "400ms" : "0ms" }}
            >
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-red-500/10 via-slate-800/50 to-slate-900/80 backdrop-blur-sm border border-red-500/20 p-8 transition-all duration-200 hover:scale-[1.02] hover:shadow-2xl hover:shadow-red-500/10 hover:border-red-400/40 h-full flex flex-col">
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />

                <div className="relative z-10 flex flex-col h-full">
                  <div className="flex items-center justify-center mb-6">
                    <div className="relative">
                      <div className="absolute inset-0 bg-red-500/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-200" />
                      <div className="relative bg-gradient-to-br from-red-500 to-red-600 p-4 rounded-2xl">
                        <Youtube className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-white mb-2">YouTube Videos</h3>
                    <p className="text-slate-300">Extract notes from video content</p>
                  </div>

                  <div className="flex-grow flex flex-col justify-center">
                    <div className="space-y-4">
                      <div className="relative mb-2">
                        <Input
                          placeholder="https://youtube.com/watch?v=..."
                          value={youtubeUrl}
                          onChange={(e) => setYoutubeUrl(e.target.value)}
                          className="bg-slate-800/50 border-slate-600/50 text-white placeholder:text-slate-400 h-12 rounded-xl backdrop-blur-sm transition-all duration-300 focus:border-red-400/50 focus:bg-slate-800/80"
                        />
                        {youtubeUrl && !isValidYoutubeUrl(youtubeUrl) && (
                          <p className="text-red-400 text-sm mt-2 animate-in slide-in-from-top duration-300">
                            Please enter a valid YouTube URL
                          </p>
                        )}
                      </div>

                      <Button
                        onClick={handleYoutubeSubmit}
                        disabled={!youtubeUrl.trim() || !isValidYoutubeUrl(youtubeUrl)}
                        className="w-full h-12 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold rounded-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-red-500/25 disabled:opacity-50 disabled:hover:scale-100"
                      >
                        <Youtube className="h-5 w-5 mr-2" />
                        Process Video
                      </Button>
                    </div>
                  </div>

                  <div className="mt-6">
                    <p className="text-sm text-slate-400 text-center">
                      Turn any lecture video into study material — no note-taking required
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Audio Section */}
            <div
              className={`group transition-all duration-1000 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: isLoaded ? "600ms" : "0ms" }}
            >
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-500/10 via-slate-800/50 to-slate-900/80 backdrop-blur-sm border border-emerald-500/20 p-8 transition-all duration-200 hover:scale-[1.02] hover:shadow-2xl hover:shadow-emerald-500/10 hover:border-emerald-400/40 h-full flex flex-col">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />

                <div className="relative z-10 flex flex-col h-full">
                  <div className="flex items-center justify-center mb-6">
                    <div className="relative">
                      <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-200" />
                      <div className="relative bg-gradient-to-br from-emerald-500 to-emerald-600 p-4 rounded-2xl">
                        <Mic className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-white mb-2">Upload Audio</h3>
                    <p className="text-slate-300">Recorded lectures and audio notes</p>
                  </div>

                  <div className="flex-grow">
                    <AudioUploadCard onAudioUpload={handleAudioUpload} />
                  </div>

                  <div className="mt-6">
                    <p className="text-sm text-slate-400 text-center">
                      Record it, upload it, study from it — we do the rest.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Simplified Loading Page */
          <div
            className={`max-w-2xl mx-auto transition-all duration-1000 ${
              isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div className="text-center mb-12">
              <div className="flex items-center justify-center mb-6">
                <div className="relative">
                  <div className="relative bg-gradient-to-br from-slate-700 to-slate-800 p-6 rounded-3xl border border-slate-600/50">
                    {processingType === "youtube" ? (
                      <Youtube className="h-12 w-12 text-red-400" />
                    ) : processingType === "audio" ? (
                      <Mic className="h-12 w-12 text-emerald-400" />
                    ) : (
                      <FileText className="h-12 w-12 text-blue-400" />
                    )}
                  </div>
                </div>
              </div>

              <h2 className="text-3xl font-bold text-white mb-2">
                {processingType === "youtube"
                  ? "Processing YouTube Video"
                  : processingType === "audio"
                    ? "Processing Audio Recording"
                    : `Processing ${uploadedFile}`}
              </h2>
              <p className="text-lg text-slate-300 mb-12">AI is analyzing your content...</p>

              {/* Progress Bar */}
              <div className="relative w-full max-w-md mx-auto">
                <div className="w-full bg-slate-800 rounded-full h-4 relative overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full transition-all duration-300 ease-out relative"
                    style={{ width: `${progress}%` }}
                  >
                    {/* Green glow effect */}
                    <div className="absolute inset-0 bg-emerald-400/30 rounded-full blur-sm"></div>
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full"></div>
                  </div>
                </div>

                {/* Percentage display */}
                <div className="mt-4">
                  <span className="text-2xl font-bold text-emerald-400">{Math.round(progress)}%</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} showLimitMessage={true} />
    </div>
  )
}
