"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { FileText, Calendar, MoreVertical, Trash2 } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

const pastUploads = [
  {
    id: "biology-chapter-5",
    name: "Biology Chapter 5 - Photosynthesis.pdf",
    uploadDate: "Created on Friday, March 15th",
    type: "PDF",
    flashcardsCount: 24,
    quizzesCount: 3,
  },
  {
    id: "chemistry-lab-report",
    name: "Chemistry Lab Report #3.docx",
    uploadDate: "Created on Tuesday, March 12th",
    type: "DOCX",
    flashcardsCount: 16,
    quizzesCount: 2,
  },
  {
    id: "physics-equations",
    name: "Physics Equations Cheat Sheet.png",
    uploadDate: "Created on Sunday, March 10th",
    type: "PNG",
    flashcardsCount: 30,
    quizzesCount: 4,
  },
  {
    id: "history-notes",
    name: "World War II Timeline Notes.txt",
    uploadDate: "Created on Friday, March 8th",
    type: "TXT",
    flashcardsCount: 40,
    quizzesCount: 5,
  },
  {
    id: "math-homework",
    name: "Calculus Problem Set 7.pdf",
    uploadDate: "Created on Tuesday, March 5th",
    type: "PDF",
    flashcardsCount: 0,
    quizzesCount: 0,
  },
]

export default function PastUploadsPage() {
  const [uploads, setUploads] = useState(pastUploads)

  const handleDelete = (uploadId: string) => {
    setUploads(uploads.filter((upload) => upload.id !== uploadId))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Past Uploads</h1>
          <p className="text-slate-400 mt-2">Access your previously uploaded study materials</p>
        </div>
        <Link href="/dashboard/upload">
          <Button>
            <FileText className="h-4 w-4 mr-2" />
            Upload New File
          </Button>
        </Link>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">5</div>
            <p className="text-sm text-slate-300">Total Uploads</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">55</div>
            <p className="text-sm text-slate-300">Notes Generated</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">110</div>
            <p className="text-sm text-slate-300">Flashcards Created</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">14</div>
            <p className="text-sm text-slate-300">Quizzes Available</p>
          </CardContent>
        </Card>
      </div>

      {/* Uploads Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {uploads.map((upload) => (
          <Card key={upload.id} className="hover:shadow-lg transition-shadow h-full bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <FileText className="h-5 w-5 text-blue-400" />
                  <Badge variant="outline" className="text-xs bg-transparent border-slate-600 text-white">
                    {upload.type}
                  </Badge>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-white hover:bg-slate-700">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-800 border-slate-700">
                    <DropdownMenuItem
                      onClick={() => handleDelete(upload.id)}
                      className="text-red-400 hover:bg-slate-700 hover:text-red-300 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <Link href={`/dashboard/uploads/${upload.id}`}>
                <CardTitle className="text-lg line-clamp-2 text-slate-100 hover:text-white cursor-pointer">
                  {upload.name}
                </CardTitle>
              </Link>
              <CardDescription className="flex items-center text-sm text-slate-400">
                <Calendar className="h-3 w-3 mr-1" />
                {upload.uploadDate}
              </CardDescription>
            </CardHeader>
            <Link href={`/dashboard/uploads/${upload.id}`}>
              <CardContent className="cursor-pointer">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Flashcards:</span>
                    <span className="font-medium text-slate-200">{upload.flashcardsCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Quizzes:</span>
                    <span className="font-medium text-slate-200">{upload.quizzesCount}</span>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>
        ))}
      </div>

      {/* Empty State for no uploads */}
      {uploads.length === 0 && (
        <Card className="text-center py-12 bg-slate-800 border-slate-700">
          <CardContent>
            <FileText className="h-16 w-16 text-slate-400 mx-auto mb-4" />
            <CardTitle className="text-xl mb-2 text-white">No uploads yet</CardTitle>
            <CardDescription className="mb-6 text-slate-400">
              Upload your first study material to get started with AI-powered learning tools
            </CardDescription>
            <Link href="/dashboard/upload">
              <Button size="lg">
                <FileText className="h-4 w-4 mr-2" />
                Upload Your First File
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
