import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { workflowId: string } }) {
  try {
    const workflowId = params.workflowId

    // This would typically call BuildShip's status API
    // For now, we'll simulate the status check
    const response = await fetch(`${process.env.BUILDSHIP_BASE_URL}/workflows/${workflowId}/status`, {
      headers: {
        Authorization: `Bearer ${process.env.BUILDSHIP_API_KEY}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch workflow status")
    }

    const data = await response.json()

    return NextResponse.json({
      status: data.status,
      progress: data.progress,
      logs: data.logs,
      result: data.result,
    })
  } catch (error) {
    console.error("Error fetching workflow status:", error)
    return NextResponse.json({ error: "Failed to fetch status" }, { status: 500 })
  }
}
