import { type NextRequest, NextResponse } from "next/server"
import { createNotes, createFlashcards, createQuizQuestions, updateUploadStatus } from "@/lib/database"

// Webhook to handle BuildShip workflow responses
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { workflowType, userId, uploadId, status, data, error } = body

    // Verify webhook signature (implement your security)
    const signature = request.headers.get("x-buildship-signature")
    if (!signature || !verifyWebhookSignature(signature, body)) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
    }

    switch (workflowType) {
      case "document-processor":
        await handleDocumentProcessingResult(uploadId, status, data, error)
        break

      case "youtube-processor":
        await handleYouTubeProcessingResult(uploadId, status, data, error)
        break

      case "audio-processor":
        await handleAudioProcessingResult(uploadId, status, data, error)
        break

      case "ai-study-generator":
        await handleStudyMaterialsResult(uploadId, status, data, error)
        break

      default:
        console.log(`Unhandled workflow type: ${workflowType}`)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("BuildShip webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

async function handleDocumentProcessingResult(uploadId: string, status: string, data: any, error: string) {
  if (status === "completed" && data) {
    // Save study materials to database
    await Promise.all([
      createNotes(
        data.notes.map((note: any, index: number) => ({
          upload_id: uploadId,
          title: note.title,
          content: note.content,
          order_index: index,
        })),
      ),
      createFlashcards(
        data.flashcards.map((card: any) => ({
          upload_id: uploadId,
          front: card.front,
          back: card.back,
          difficulty: 1,
          times_reviewed: 0,
        })),
      ),
      createQuizQuestions(
        data.quiz.map((question: any) => ({
          upload_id: uploadId,
          question: question.question,
          options: question.options,
          correct_answer: question.correctAnswer,
          explanation: question.explanation,
          times_answered: 0,
          times_correct: 0,
        })),
      ),
    ])

    await updateUploadStatus(uploadId, "completed")
  } else {
    await updateUploadStatus(uploadId, "failed")
  }
}

async function handleYouTubeProcessingResult(uploadId: string, status: string, data: any, error: string) {
  // Similar handling for YouTube processing results
  if (status === "completed" && data) {
    await handleDocumentProcessingResult(uploadId, status, data, error)
  } else {
    await updateUploadStatus(uploadId, "failed")
  }
}

async function handleAudioProcessingResult(uploadId: string, status: string, data: any, error: string) {
  // Similar handling for audio processing results
  if (status === "completed" && data) {
    await handleDocumentProcessingResult(uploadId, status, data, error)
  } else {
    await updateUploadStatus(uploadId, "failed")
  }
}

async function handleStudyMaterialsResult(uploadId: string, status: string, data: any, error: string) {
  // Handle AI-generated study materials
  if (status === "completed" && data) {
    await handleDocumentProcessingResult(uploadId, status, data, error)
  } else {
    await updateUploadStatus(uploadId, "failed")
  }
}

function verifyWebhookSignature(signature: string, body: any): boolean {
  // Implement your webhook signature verification logic
  // This should match the signature method used by BuildShip
  const expectedSignature = process.env.BUILDSHIP_WEBHOOK_SECRET
  return signature === expectedSignature
}
