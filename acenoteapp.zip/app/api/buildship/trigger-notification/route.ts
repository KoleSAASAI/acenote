import { type NextRequest, NextResponse } from "next/server"
import { buildShipClient } from "@/lib/buildship"
import { supabase } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { userId, notificationType, data } = await request.json()

    // Get user email
    const { data: profile, error } = await supabase.from("profiles").select("email").eq("id", userId).single()

    if (error || !profile) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Trigger BuildShip notification workflow
    const response = await buildShipClient.sendNotification({
      userId,
      email: profile.email,
      type: notificationType,
      data,
    })

    if (!response.success) {
      throw new Error(response.error || "Notification failed")
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Notification trigger error:", error)
    return NextResponse.json({ error: "Failed to send notification" }, { status: 500 })
  }
}
