import { type NextRequest, NextResponse } from "next/server"
import { generateAllStudyMaterials } from "@/lib/openai"
import { processYouTubeVideo } from "@/lib/youtube-processor"
import { checkYouTubeTranscriptionLimit, incrementYouTubeUsage } from "@/lib/subscription"

export async function POST(request: NextRequest) {
  try {
    const { url, userId } = await request.json()

    if (!url) {
      return NextResponse.json({ error: "No URL provided" }, { status: 400 })
    }

    if (!userId) {
      return NextResponse.json({ error: "User ID required" }, { status: 400 })
    }

    // Extract video ID from YouTube URL
    const videoId = extractVideoId(url)
    if (!videoId) {
      return NextResponse.json({ error: "Invalid YouTube URL" }, { status: 400 })
    }

    // Process YouTube video (get info, download audio, transcribe with gpt-4o-mini-transcribe)
    const { title, duration, transcript } = await processYouTubeVideo(url)
    const durationMinutes = Math.ceil(duration / 60)

    // Check transcription limits
    const limitCheck = await checkYouTubeTranscriptionLimit(userId, durationMinutes)
    if (!limitCheck.canTranscribe) {
      return NextResponse.json(
        {
          error: limitCheck.reason,
          remainingMinutes: limitCheck.remainingMinutes,
        },
        { status: 403 },
      )
    }

    // Determine if user has unlimited plan
    const isUnlimited = limitCheck.plan?.name === "Ultimate Plan"
    const shouldSkim = false // YouTube transcripts are usually not as long as documents

    // Generate study materials using gpt-4o-mini
    const studyMaterials = await generateAllStudyMaterials(
      transcript,
      title,
      limitCheck.plan?.max_flashcards || 50,
      limitCheck.plan?.max_quiz_questions || 10,
      shouldSkim,
      isUnlimited,
    )

    // Increment YouTube usage
    await incrementYouTubeUsage(userId, durationMinutes)

    const uploadData = {
      id: `youtube-${videoId}`,
      fileName: title,
      type: "YOUTUBE",
      uploadDate: new Date().toISOString(),
      textContent: transcript,
      duration: durationMinutes,
      notes: studyMaterials.notes || [],
      flashcards: studyMaterials.flashcards || [],
      quiz: studyMaterials.quiz || [],
    }

    return NextResponse.json(uploadData)
  } catch (error) {
    console.error("Error processing YouTube video:", error)
    return NextResponse.json(
      {
        error: "Failed to process YouTube video",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

function extractVideoId(url: string): string | null {
  const regex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/
  const match = url.match(regex)
  return match ? match[1] : null
}
