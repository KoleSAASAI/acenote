import { type NextRequest, NextResponse } from "next/server"
import { buildShipClient } from "@/lib/buildship"
import { createUpload } from "@/lib/database"
import { checkUploadLimits, incrementUploadUsage, getUserSubscription } from "@/lib/subscription"
import { supabase } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    // Get the user from the session
    const authHeader = request.headers.get("authorization")
    if (!authHeader) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.replace("Bearer ", "")
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File
    const fileName = formData.get("fileName") as string
    const processingType = formData.get("processingType") as string // 'document' | 'youtube' | 'audio'

    if (!file && processingType !== "youtube") {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Get user subscription
    const subscription = await getUserSubscription(user.id)
    const planType = subscription?.plan?.name || "Free Plan"

    // Check upload limits
    const limitCheck = await checkUploadLimits(user.id, file?.size || 0, processingType)
    if (!limitCheck.canUpload) {
      return NextResponse.json({ error: limitCheck.reason }, { status: 403 })
    }

    // Create upload record
    const upload = await createUpload({
      user_id: user.id,
      file_name: fileName,
      file_type: file?.type || "youtube",
      file_size: file?.size || 0,
      upload_date: new Date().toISOString(),
      status: "processing",
    })

    let buildShipResponse

    try {
      switch (processingType) {
        case "document":
          const textContent = await extractTextContent(file)
          buildShipResponse = await buildShipClient.processDocument({
            userId: user.id,
            fileName: fileName,
            fileContent: textContent,
            fileType: file.type,
            planType: planType,
          })
          break

        case "youtube":
          const youtubeUrl = formData.get("youtubeUrl") as string
          buildShipResponse = await buildShipClient.processYouTubeVideo({
            userId: user.id,
            videoUrl: youtubeUrl,
            planType: planType,
            maxDuration: limitCheck.plan?.max_youtube_duration_minutes || 10,
          })
          break

        case "audio":
          const audioBase64 = await fileToBase64(file)
          buildShipResponse = await buildShipClient.processAudio({
            userId: user.id,
            audioFile: audioBase64,
            fileName: fileName,
            planType: planType,
          })
          break

        default:
          throw new Error("Invalid processing type")
      }

      if (!buildShipResponse.success) {
        throw new Error(buildShipResponse.error || "BuildShip processing failed")
      }

      // Track user activity
      await buildShipClient.trackUserActivity({
        userId: user.id,
        action: `upload_${processingType}`,
        metadata: { fileName, planType },
      })

      // Increment usage tracking
      await incrementUploadUsage(user.id)

      return NextResponse.json({
        id: upload.id,
        fileName: upload.file_name,
        type: upload.file_type,
        uploadDate: upload.upload_date,
        status: "processing",
        workflowId: buildShipResponse.workflowId,
      })
    } catch (processingError) {
      console.error("BuildShip processing error:", processingError)
      throw processingError
    }
  } catch (error) {
    console.error("Error processing upload with BuildShip:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Failed to process upload",
      },
      { status: 500 },
    )
  }
}

async function extractTextContent(file: File): Promise<string> {
  if (file.type === "application/pdf") {
    // Dynamic import to avoid build-time issues
    const pdfParse = await import("pdf-parse")
    const pdf = pdfParse.default || pdfParse
    const buffer = await file.arrayBuffer()
    const data = await pdf(Buffer.from(buffer))
    return data.text
  } else if (file.type === "text/plain") {
    return await file.text()
  } else {
    throw new Error("Unsupported file type")
  }
}

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = (error) => reject(error)
  })
}
