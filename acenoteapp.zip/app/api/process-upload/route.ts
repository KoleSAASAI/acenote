import { type NextRequest, NextResponse } from "next/server"
import { generateAllStudyMaterials } from "@/lib/openai"
import { createUpload, createNotes, createFlashcards, createQuizQuestions, updateUploadStatus } from "@/lib/database"
import { checkUploadLimits, incrementUploadUsage } from "@/lib/subscription"
import { supabase } from "@/lib/supabase"

// Dynamic import to avoid build-time issues
async function parsePDF(buffer: ArrayBuffer): Promise<string> {
  try {
    // Dynamic import to prevent build-time issues
    const pdfParse = await import("pdf-parse")
    const pdf = pdfParse.default || pdfParse
    const data = await pdf(Buffer.from(buffer))
    return data.text
  } catch (error) {
    console.error("PDF parsing error:", error)
    throw new Error("Failed to parse PDF file")
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get the user from the session
    const authHeader = request.headers.get("authorization")
    if (!authHeader) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.replace("Bearer ", "")
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File
    const fileName = formData.get("fileName") as string
    const youtubeDuration = formData.get("youtubeDuration") as string

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ["application/pdf", "text/plain"]
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: "Unsupported file type" }, { status: 400 })
    }

    // Check upload limits with YouTube duration
    const limitCheck = await checkUploadLimits(
      user.id,
      file.size,
      file.type,
      youtubeDuration ? Number.parseInt(youtubeDuration) : undefined,
    )
    if (!limitCheck.canUpload) {
      return NextResponse.json({ error: limitCheck.reason }, { status: 403 })
    }

    const plan = limitCheck.plan!
    const isUnlimited = plan.name === "Ultimate Plan"

    // Create upload record
    const upload = await createUpload({
      user_id: user.id,
      file_name: fileName,
      file_type: file.type,
      file_size: file.size,
      upload_date: new Date().toISOString(),
      status: "processing",
    })

    // Extract text content based on file type
    let textContent = ""

    try {
      if (file.type === "application/pdf") {
        const buffer = await file.arrayBuffer()
        textContent = await parsePDF(buffer)
      } else if (file.type === "text/plain") {
        textContent = await file.text()
      } else {
        throw new Error("Unsupported file type")
      }

      if (!textContent || !textContent.trim()) {
        throw new Error("No text content found in file")
      }

      // Determine if we should skim the content (for files >200MB equivalent)
      const shouldSkim = file.size > 200 * 1024 * 1024 // 200MB

      // Generate study materials with plan limits
      const studyMaterials = await generateAllStudyMaterials(
        textContent,
        fileName,
        plan.max_flashcards,
        plan.max_quiz_questions,
        shouldSkim,
        isUnlimited,
      )

      // Save to database
      await Promise.all([
        createNotes(
          studyMaterials.notes.map((note: any, index: number) => ({
            upload_id: upload.id,
            title: note.title,
            content: note.content,
            order_index: index,
          })),
        ),
        createFlashcards(
          studyMaterials.flashcards.map((card: any) => ({
            upload_id: upload.id,
            front: card.front,
            back: card.back,
            difficulty: 1,
            times_reviewed: 0,
          })),
        ),
        createQuizQuestions(
          studyMaterials.quiz.map((question: any) => ({
            upload_id: upload.id,
            question: question.question,
            options: question.options,
            correct_answer: question.correctAnswer,
            explanation: question.explanation,
            times_answered: 0,
            times_correct: 0,
          })),
        ),
      ])

      // Update upload status to completed
      await updateUploadStatus(upload.id, "completed")

      // Increment usage tracking
      await incrementUploadUsage(user.id)

      return NextResponse.json({
        id: upload.id,
        fileName: upload.file_name,
        type: upload.file_type,
        uploadDate: upload.upload_date,
        status: "completed",
        flashcardsGenerated: studyMaterials.flashcards.length,
        quizQuestionsGenerated: studyMaterials.quiz.length,
      })
    } catch (processingError) {
      console.error("Processing error:", processingError)
      // Update upload status to failed
      await updateUploadStatus(upload.id, "failed")
      throw processingError
    }
  } catch (error) {
    console.error("Error processing upload:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Failed to process upload",
      },
      { status: 500 },
    )
  }
}
