import { type NextRequest, NextResponse } from "next/server"
import { chatWithContent } from "@/lib/openai"
import { checkChatLimits, incrementChatUsage } from "@/lib/subscription"
import { supabase } from "@/lib/supabase"
import { getUserSubscription } from "@/lib/subscription"

export async function POST(request: NextRequest) {
  try {
    const { message, uploadId, context } = await request.json()

    if (!message || !context) {
      return NextResponse.json({ error: "Message and context are required" }, { status: 400 })
    }

    // Get user from session
    const authHeader = request.headers.get("authorization")
    if (!authHeader) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.replace("Bearer ", "")
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user subscription to check if unlimited
    const subscription = await getUserSubscription(user.id)
    const isUnlimited = subscription?.plan?.name === "Ultimate Plan"

    // Check chat limits only for non-unlimited users
    if (!isUnlimited) {
      const limitCheck = await checkChatLimits(user.id)
      if (!limitCheck.canChat) {
        return NextResponse.json({ error: limitCheck.reason }, { status: 403 })
      }
    }

    const response = await chatWithContent(message, context, isUnlimited)

    // Increment chat usage only for non-unlimited users
    if (!isUnlimited) {
      await incrementChatUsage(user.id)
    }

    return NextResponse.json({
      response,
      timestamp: new Date().toISOString(),
      remaining: isUnlimited ? "unlimited" : (await checkChatLimits(user.id)).remaining - 1,
    })
  } catch (error) {
    console.error("Error in chat:", error)
    return NextResponse.json({ error: "Failed to generate response" }, { status: 500 })
  }
}
