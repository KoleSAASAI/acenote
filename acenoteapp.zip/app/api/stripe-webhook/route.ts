import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { supabase } from "@/lib/supabase"
import type Stripe from "stripe"

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("stripe-signature")!

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err) {
      console.error("Webhook signature verification failed:", err)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session)
        break

      case "customer.subscription.updated":
        await handleSubscriptionUpdated(event.data.object as Stripe.Subscription)
        break

      case "customer.subscription.deleted":
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription)
        break

      case "invoice.payment_failed":
        await handlePaymentFailed(event.data.object as Stripe.Invoice)
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook error" }, { status: 500 })
  }
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const userId = session.client_reference_id || session.metadata?.user_id
  const planType = session.metadata?.plan_type

  if (!userId) {
    console.error("No user ID found in checkout session")
    return
  }

  try {
    // Get the subscription from Stripe
    const subscription = await stripe.subscriptions.retrieve(session.subscription as string)

    // Get the Ultimate Plan ID
    const { data: ultimatePlan } = await supabase
      .from("subscription_plans")
      .select("id")
      .eq("name", "Ultimate Plan")
      .single()

    if (!ultimatePlan) {
      console.error("Ultimate Plan not found in database")
      return
    }

    // Create or update user subscription
    const { error } = await supabase.from("user_subscriptions").upsert({
      user_id: userId,
      plan_id: ultimatePlan.id,
      stripe_subscription_id: subscription.id,
      stripe_customer_id: subscription.customer as string,
      status: "active",
      current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (error) {
      console.error("Error updating user subscription:", error)
    } else {
      console.log(`Successfully upgraded user ${userId} to Ultimate Plan`)
    }
  } catch (error) {
    console.error("Error handling checkout completion:", error)
  }
}

async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  try {
    const { error } = await supabase
      .from("user_subscriptions")
      .update({
        status: subscription.status,
        current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_subscription_id", subscription.id)

    if (error) {
      console.error("Error updating subscription:", error)
    }
  } catch (error) {
    console.error("Error handling subscription update:", error)
  }
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  try {
    // Get the Free Plan ID
    const { data: freePlan } = await supabase.from("subscription_plans").select("id").eq("name", "Free Plan").single()

    if (!freePlan) {
      console.error("Free Plan not found in database")
      return
    }

    // Downgrade user to Free Plan
    const { error } = await supabase
      .from("user_subscriptions")
      .update({
        plan_id: freePlan.id,
        status: "cancelled",
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_subscription_id", subscription.id)

    if (error) {
      console.error("Error downgrading subscription:", error)
    }
  } catch (error) {
    console.error("Error handling subscription deletion:", error)
  }
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  try {
    const { error } = await supabase
      .from("user_subscriptions")
      .update({
        status: "past_due",
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_customer_id", invoice.customer as string)

    if (error) {
      console.error("Error updating subscription status:", error)
    }
  } catch (error) {
    console.error("Error handling payment failure:", error)
  }
}
