"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

export default function PasswordResetPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [emailSent, setEmailSent] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setMessage("")

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      })

      if (error) {
        setError(error.message)
      } else {
        setEmailSent(true)
        setMessage("Password reset email sent! Check your inbox.")
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  if (emailSent) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-slate-800/50 border border-slate-600 rounded-3xl p-8 space-y-6 text-center">
            <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-emerald-400" />
            </div>

            <div className="space-y-3">
              <h2 className="text-2xl font-bold text-white">Check your email</h2>
              <p className="text-slate-300">
                We've sent a password reset link to <span className="text-emerald-400">{email}</span>
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-slate-400">Didn't receive the email? Check your spam folder or try again.</p>

              <Button
                onClick={() => {
                  setEmailSent(false)
                  setEmail("")
                  setMessage("")
                }}
                variant="outline"
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Try again
              </Button>

              <Link href="/signin" className="block">
                <Button
                  variant="ghost"
                  className="w-full text-emerald-400 hover:text-emerald-300 hover:bg-slate-700/50"
                >
                  Back to sign in
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Password Reset container */}
        <div className="bg-slate-800/50 border border-slate-600 rounded-3xl p-8 space-y-6">
          {/* Header - Left aligned */}
          <div className="space-y-3">
            <h2 className="text-3xl font-bold text-white text-left">Change your password</h2>
            <p className="text-slate-300 text-left">Enter your email and we'll send you a password reset link.</p>
          </div>

          {/* Error Messages */}
          {error && (
            <Alert className="border-red-500/20 bg-red-500/10 rounded-xl">
              <AlertCircle className="h-4 w-4 text-red-400" />
              <AlertDescription className="text-red-300">{error}</AlertDescription>
            </Alert>
          )}

          {message && (
            <Alert className="border-emerald-500/20 bg-emerald-500/10 rounded-xl">
              <CheckCircle className="h-4 w-4 text-emerald-400" />
              <AlertDescription className="text-emerald-300">{message}</AlertDescription>
            </Alert>
          )}

          {/* Email Reset Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="sarthak@example.com"
                required
                className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
            </div>

            {/* Send Reset Email Button */}
            <Button
              type="submit"
              disabled={isLoading || !email}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl py-3 h-12 font-medium disabled:opacity-50"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Sending...
                </div>
              ) : (
                "Send Reset Email"
              )}
            </Button>
          </form>

          {/* Footer */}
          <div className="text-center">
            <p className="text-slate-400 text-sm">
              Remember your password?{" "}
              <Link href="/signin" className="text-emerald-400 hover:text-emerald-300 underline">
                Back to sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
