"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  BookOpen,
  Brain,
  MessageSquare,
  Zap,
  ArrowRight,
  CheckCircle,
  TrendingUp,
  Users,
  Clock,
  Upload,
  Quote,
} from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export default function LandingPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  // Refs for scroll-triggered sections
  const featuresRef = useRef<HTMLElement>(null)
  const benefitsRef = useRef<HTMLElement>(null)
  const testimonialsRef = useRef<HTMLElement>(null)

  // State to track which sections are visible
  const [visibleSections, setVisibleSections] = useState({
    features: false,
    benefits: false,
    testimonials: false,
  })

  useEffect(() => {
    // If user is authenticated, redirect to dashboard
    if (!loading && user) {
      // Use replace instead of push to avoid back button issues
      router.replace("/dashboard")
    }
  }, [user, loading, router])

  useEffect(() => {
    const observerOptions = {
      threshold: 0.2,
      rootMargin: "0px 0px -100px 0px",
    }

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const sectionId = entry.target.getAttribute("data-section")
          if (sectionId) {
            setVisibleSections((prev) => ({
              ...prev,
              [sectionId]: true,
            }))
          }
        }
      })
    }

    const observer = new IntersectionObserver(observerCallback, observerOptions)

    // Small delay to ensure refs are ready
    setTimeout(() => {
      if (featuresRef.current) observer.observe(featuresRef.current)
      if (benefitsRef.current) observer.observe(benefitsRef.current)
      if (testimonialsRef.current) observer.observe(testimonialsRef.current)
    }, 100)

    return () => {
      observer.disconnect()
    }
  }, [])

  // Show loading spinner while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-[#3ef2b5] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-100 text-lg">Checking authentication...</p>
        </div>
      </div>
    )
  }

  // If user is authenticated, show a brief redirect message
  if (user) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-[#3ef2b5] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-100 text-lg">Redirecting to dashboard...</p>
        </div>
      </div>
    )
  }

  // Show landing page for non-authenticated users
  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Consistent Animated background elements throughout */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#3ef2b5]/8 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#3ef2b5]/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#3ef2b5]/3 rounded-full blur-3xl animate-pulse delay-500"></div>
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-[#3ef2b5]/4 rounded-full blur-3xl animate-pulse delay-700"></div>
        <div className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-[#3ef2b5]/6 rounded-full blur-3xl animate-pulse delay-300"></div>
      </div>

      {/* Header */}
      <header className="container mx-auto px-4 py-6 relative z-10">
        <nav className="flex items-center justify-between animate-fade-in">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-[#3ef2b5] rounded-lg flex items-center justify-center animate-bounce-subtle">
              <BookOpen className="h-5 w-5 text-[#1e293b]" />
            </div>
            <span className="text-2xl font-bold text-slate-100">AceNote</span>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/signin">
              <Button
                variant="ghost"
                className="text-slate-100 hover:text-[#3ef2b5] hover:bg-slate-800/50 transition-all duration-300"
              >
                Sign In
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#3ef2b5] hover:bg-[#1db58b] text-[#1e293b] font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-[#3ef2b5]/25">
                Get Started - It's Free!
              </Button>
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-24 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-left">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-100 mb-6 opacity-0 animate-slide-up leading-tight">
              <div className="whitespace-nowrap mb-3">Study Smarter…</div>
              <div className="whitespace-nowrap">
                <em>Like, Actually Smarter</em>
              </div>
            </h1>

            {/* CTA Button */}
            <div className="opacity-0 animate-slide-up delay-200 mb-6">
              <Link href="/signup">
                <Button
                  size="lg"
                  className="bg-[#3ef2b5] hover:bg-[#1db58b] text-[#1e293b] font-semibold text-lg px-6 py-6 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#3ef2b5]/30 group"
                >
                  <Upload className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                  Upload Your First File — It's Free
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>
              </Link>
            </div>

            {/* Description */}
            <p className="text-lg text-slate-300 max-w-2xl opacity-0 animate-slide-up delay-300">
              Drop a PDF, video, audio. Get flashcards, quizzes, and a chatbot.
            </p>
          </div>

          {/* Right Video - Blended with Background */}
          <div className="relative opacity-0 animate-slide-up delay-600">
            <div className="relative">
              {/* Background Blend Elements */}
              <div className="absolute -inset-8 bg-[#3ef2b5]/3 rounded-3xl blur-xl"></div>
              <div className="absolute -inset-4 bg-slate-800/30 rounded-2xl backdrop-blur-sm"></div>

              {/* Video Container */}
              <div className="relative bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-[#3ef2b5]/30 transition-all duration-500 group">
                <div className="aspect-video bg-slate-800/80 rounded-xl flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-[#3ef2b5]/10 to-[#1db58b]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10 text-center">
                    <div className="w-16 h-16 bg-[#3ef2b5] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                      <svg className="w-8 h-8 text-[#1e293b] ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                    <p className="text-slate-300 text-lg font-semibold">PDF → Flashcards in 20s</p>
                    <p className="text-slate-400 text-sm mt-2">See how AceNote transforms your materials</p>
                  </div>
                </div>

                {/* Floating Elements for Background Blend */}
                <div className="absolute -top-2 -right-2 w-4 h-4 bg-[#3ef2b5]/20 rounded-full animate-pulse"></div>
                <div className="absolute -bottom-3 -left-3 w-6 h-6 bg-[#3ef2b5]/10 rounded-full animate-pulse delay-1000"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* University Showcase Section */}
      <section className="container mx-auto px-4 py-16 relative z-10">
        <div className="text-center animate-slide-up">
          <h2 className="text-2xl md:text-3xl font-bold text-slate-100 mb-4">Trusted by students at 1,000+ colleges</h2>

          {/* University Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center opacity-70 hover:opacity-90 transition-opacity duration-300">
            {/* Row 1 */}
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Princeton</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Stanford</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Harvard</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">MIT</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Yale</span>
            </div>

            {/* Row 2 */}
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">UCLA</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">NYU</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Berkeley</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Columbia</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Penn</span>
            </div>

            {/* Row 3 */}
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Georgia Tech</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Michigan</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Cornell</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Duke</span>
            </div>
            <div className="flex items-center justify-center p-4 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
              <span className="text-slate-300 font-semibold text-sm">Northwestern</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section ref={featuresRef} data-section="features" className="container mx-auto px-4 py-20 relative z-10">
        <div
          className={`text-center mb-16 opacity-0 translate-y-8 ${visibleSections.features ? "animate-slide-up" : ""}`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">
            Everything You Need to Learn Smarter & Faster
          </h2>
          <p className="text-slate-300 text-lg max-w-2xl mx-auto">
            <em>Built for students, by students</em> in AP, IB, and college-level programs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: Brain,
              title: "Smart Flashcards",
              desc: "AI generates personalized flashcards from your study materials for effective memorization",
              delay: "delay-100",
            },
            {
              icon: Zap,
              title: "Interactive Quizzes",
              desc: "Test your knowledge with automatically generated quizzes and track your progress",
              delay: "delay-200",
            },
            {
              icon: MessageSquare,
              title: "AI Chat Assistant",
              desc: "Ask questions about your materials and get instant, contextual answers",
              delay: "delay-300",
            },
            {
              icon: BookOpen,
              title: "Multi-Format Support",
              desc: "Upload PDFs, documents, YouTube videos, or audio recordings",
              delay: "delay-400",
            },
          ].map((feature, index) => (
            <div
              key={index}
              className={`opacity-0 translate-y-8 ${visibleSections.features ? `animate-slide-up ${feature.delay}` : ""}`}
            >
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#3ef2b5]/10 group cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-[#3ef2b5] rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                    <feature.icon className="h-6 w-6 text-[#1e293b] group-hover:scale-110 transition-transform duration-300" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-100 mb-2 group-hover:text-[#3ef2b5] transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-slate-300 group-hover:text-slate-200 transition-colors duration-300">
                    {feature.desc}
                  </p>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section ref={benefitsRef} data-section="benefits" className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className={`opacity-0 translate-y-8 ${visibleSections.benefits ? "animate-slide-up" : ""}`}>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-6">
              What Makes AceNote the Smartest Study Tool
            </h2>
            <div className="space-y-4">
              {[
                {
                  title: "Save Hours of Study Time",
                  desc: "Let AI create your study materials instantly instead of spending hours making notes",
                },
                {
                  title: "Improve Retention by 10x",
                  desc: "Active recall through flashcards and quizzes helps you remember more effectively",
                },
                {
                  title: "Track Your Progress",
                  desc: "Monitor your learning with detailed analytics and performance insights",
                },
              ].map((benefit, index) => (
                <div
                  key={index}
                  className={`opacity-0 translate-y-8 ${visibleSections.benefits ? `animate-slide-up delay-${(index + 1) * 100}` : ""}`}
                >
                  <div className="flex items-start space-x-3 group hover:bg-slate-800/30 p-3 rounded-lg transition-all duration-300">
                    <CheckCircle className="h-6 w-6 text-[#3ef2b5] mt-1 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                    <div>
                      <h3 className="text-lg font-semibold text-slate-100 group-hover:text-[#3ef2b5] transition-colors duration-300">
                        {benefit.title}
                      </h3>
                      <p className="text-slate-300 group-hover:text-slate-200 transition-colors duration-300">
                        {benefit.desc}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Enhanced Stats Section */}
          <div
            className={`relative opacity-0 translate-y-8 ${visibleSections.benefits ? "animate-slide-up delay-300" : ""}`}
          >
            <div className="grid grid-cols-1 gap-6">
              <div className="bg-gradient-to-r from-[#3ef2b5] to-[#1db58b] rounded-2xl p-6 text-center hover:scale-105 transition-transform duration-300 group">
                <div className="flex items-center justify-center mb-2">
                  <TrendingUp className="h-8 w-8 text-[#1e293b] mr-2 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-3xl font-bold text-[#1e293b]">10x</div>
                </div>
                <div className="text-[#1e293b] font-semibold mb-2">Faster Learning</div>
                <div className="text-[#1e293b]/80 text-sm">Average improvement in study efficiency</div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-center hover:bg-slate-800/70 hover:border-[#3ef2b5]/30 transition-all duration-300 group backdrop-blur-sm">
                  <Users className="h-6 w-6 text-[#3ef2b5] mx-auto mb-2 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-2xl font-bold text-slate-100">100,000+</div>
                  <div className="text-slate-300 text-sm">Active Students</div>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-center hover:bg-slate-800/70 hover:border-[#3ef2b5]/30 transition-all duration-300 group backdrop-blur-sm">
                  <Clock className="h-6 w-6 text-[#3ef2b5] mx-auto mb-2 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-2xl font-bold text-slate-100">20M+</div>
                  <div className="text-slate-300 text-sm">Hours Saved</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section ref={testimonialsRef} data-section="testimonials" className="container mx-auto px-4 py-20 relative z-10">
        <div
          className={`text-center mb-16 opacity-0 translate-y-8 ${visibleSections.testimonials ? "animate-slide-up" : ""}`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">Used by 100,000+ students worldwide</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              quote: "AceNote saved me during finals — I generated all my study sets in 10 minutes.",
              author: "Alex Chen",
              role: "UCLA Student",
              avatar: "bg-blue-500",
              delay: "delay-100",
            },
            {
              quote: "Best AI study tool I've used so far. Flashcards and quizzes feel like magic.",
              author: "Sara Martinez",
              role: "IB Student",
              avatar: "bg-purple-500",
              delay: "delay-200",
            },
            {
              quote: "Finally, a tool that actually understands my study materials. Game changer!",
              author: "Jake Thompson",
              role: "Georgia Tech CS",
              avatar: "bg-green-500",
              delay: "delay-300",
            },
            {
              quote: "I went from struggling with organic chemistry to acing my exams. AceNote is incredible.",
              author: "Emily Rodriguez",
              role: "Pre-Med Student",
              avatar: "bg-red-500",
              delay: "delay-100",
            },
            {
              quote: "The AI chatbot answers questions better than most TAs. Saved me so much time.",
              author: "David Kim",
              role: "MIT Engineering",
              avatar: "bg-yellow-500",
              delay: "delay-200",
            },
            {
              quote: "Turned my messy lecture notes into perfect study materials in seconds. Mind blown!",
              author: "Sophie Chen",
              role: "Stanford Student",
              avatar: "bg-pink-500",
              delay: "delay-300",
            },
          ].map((testimonial, index) => (
            <div
              key={index}
              className={`opacity-0 translate-y-8 ${visibleSections.testimonials ? `animate-slide-up ${testimonial.delay}` : ""}`}
            >
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-300 hover:scale-105 group h-full">
                <CardContent className="p-6">
                  <Quote className="h-8 w-8 text-[#3ef2b5] mb-4 group-hover:scale-110 transition-transform duration-300" />
                  <p className="text-slate-300 mb-4 italic">"{testimonial.quote}"</p>
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-10 h-10 ${testimonial.avatar} rounded-full flex items-center justify-center text-white font-semibold`}
                    >
                      {testimonial.author
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                    <div>
                      <p className="text-slate-100 font-semibold">{testimonial.author}</p>
                      <p className="text-slate-400 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center relative z-10">
        <div className="max-w-3xl mx-auto">
          <div className="bg-slate-800/50 rounded-3xl p-12 border border-slate-700 hover:border-[#3ef2b5]/30 transition-all duration-500 animate-slide-up group backdrop-blur-sm">
            <div className="absolute inset-0 bg-gradient-to-r from-[#3ef2b5]/5 to-[#1db58b]/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4 group-hover:text-[#3ef2b5] transition-colors duration-300">
                Ready to Transform Your Study Routine?
              </h2>
              <p className="text-slate-300 text-lg mb-8 group-hover:text-slate-200 transition-colors duration-300">
                Join thousands of students who are already studying smarter with AceNote
              </p>
              <Link href="/signup">
                <Button
                  size="lg"
                  className="bg-[#3ef2b5] hover:bg-[#1db58b] text-[#1e293b] font-semibold text-lg px-8 py-3 transition-all duration-300 hover:scale-110 hover:shadow-2xl hover:shadow-[#3ef2b5]/40 group/btn"
                >
                  Start for Free — No Card Needed
                  <ArrowRight className="ml-2 h-5 w-5 group-hover/btn:translate-x-2 transition-transform duration-300" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 relative z-10">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-2 animate-fade-in">
            <div className="w-6 h-6 bg-[#3ef2b5] rounded flex items-center justify-center">
              <BookOpen className="h-4 w-4 text-[#1e293b]" />
            </div>
            <span className="text-lg font-semibold text-slate-100">AceNote</span>
          </div>
          <p className="text-slate-400 text-sm italic mb-4">Upload. Learn. Ace.</p>
          <div className="flex items-center justify-center space-x-8">
            <Link href="/terms" className="text-slate-400 hover:text-slate-300 transition-colors duration-300">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-slate-400 hover:text-slate-300 transition-colors duration-300">
              Privacy Policy
            </Link>
          </div>
        </div>
      </footer>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slide-up {
          from { 
            opacity: 0; 
            transform: translateY(32px);
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }
        
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
        
        .animate-slide-up {
          animation: slide-up 0.8s ease-out forwards;
        }
        
        .animate-bounce-subtle {
          animation: bounce-subtle 2s ease-in-out infinite;
        }
        
        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 3s ease infinite;
        }
        
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-400 { animation-delay: 0.4s; }
        .delay-500 { animation-delay: 0.5s; }
        .delay-600 { animation-delay: 0.6s; }
        .delay-1000 { animation-delay: 1s; }
      `}</style>
    </div>
  )
}
