import { supabase, isSupabaseConfigured } from "./supabase"

export interface Upload {
  id: string
  user_id: string
  file_name: string
  file_type: string
  file_size?: number
  upload_date: string
  status: "processing" | "completed" | "failed"
  text_content?: string
  created_at: string
  updated_at: string
}

export interface Note {
  id: string
  upload_id: string
  title: string
  content: string
  order_index: number
  created_at: string
}

export interface Flashcard {
  id: string
  upload_id: string
  front: string
  back: string
  difficulty: number
  times_reviewed: number
  last_reviewed?: string
  created_at: string
}

export interface QuizQuestion {
  id: string
  upload_id: string
  question: string
  options: string[]
  correct_answer: number
  explanation: string
  times_answered: number
  times_correct: number
  created_at: string
}

// Helper function to check if database operations are available
function checkDatabaseAvailable() {
  if (!isSupabaseConfigured()) {
    throw new Error("Database is not configured. Please set up Supabase.")
  }
}

// Upload functions
export async function createUpload(upload: Omit<Upload, "id" | "created_at" | "updated_at">) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("uploads").insert(upload).select().single()

  if (error) throw error
  return data
}

export async function getUserUploads(userId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("uploads")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function getUploadById(uploadId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("uploads").select("*").eq("id", uploadId).single()

  if (error) throw error
  return data
}

export async function updateUploadStatus(uploadId: string, status: Upload["status"]) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("uploads")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", uploadId)
    .select()
    .single()

  if (error) throw error
  return data
}

// Notes functions
export async function createNotes(notes: Omit<Note, "id" | "created_at">[]) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("notes").insert(notes).select()

  if (error) throw error
  return data
}

export async function getNotesByUploadId(uploadId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("notes")
    .select("*")
    .eq("upload_id", uploadId)
    .order("order_index", { ascending: true })

  if (error) throw error
  return data
}

// Flashcards functions
export async function createFlashcards(flashcards: Omit<Flashcard, "id" | "created_at">[]) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("flashcards").insert(flashcards).select()

  if (error) throw error
  return data
}

export async function getFlashcardsByUploadId(uploadId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("flashcards")
    .select("*")
    .eq("upload_id", uploadId)
    .order("created_at", { ascending: true })

  if (error) throw error
  return data
}

// Quiz functions
export async function createQuizQuestions(questions: Omit<QuizQuestion, "id" | "created_at">[]) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("quiz_questions").insert(questions).select()

  if (error) throw error
  return data
}

export async function getQuizQuestionsByUploadId(uploadId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("quiz_questions")
    .select("*")
    .eq("upload_id", uploadId)
    .order("created_at", { ascending: true })

  if (error) throw error
  return data
}

// Profile functions
export async function getProfile(userId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (error) throw error
  return data
}

export async function updateProfile(
  userId: string,
  updates: Partial<{
    full_name: string
    university: string
    major: string
  }>,
) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("profiles")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", userId)
    .select()
    .single()

  if (error) throw error
  return data
}

// Chat functions
export async function saveChatMessage(uploadId: string, userId: string, message: string, response: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("chat_messages")
    .insert({
      upload_id: uploadId,
      user_id: userId,
      message,
      response,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getChatHistory(uploadId: string) {
  checkDatabaseAvailable()
  const { data, error } = await supabase
    .from("chat_messages")
    .select("*")
    .eq("upload_id", uploadId)
    .order("created_at", { ascending: true })

  if (error) throw error
  return data
}
