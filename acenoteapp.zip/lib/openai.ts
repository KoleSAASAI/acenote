import OpenAI from "openai"

if (!process.env.OPENAI_API_KEY) {
  throw new Error("Missing OPENAI_API_KEY environment variable")
}

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

// Main function - generates everything at once with plan limits
export async function generateAllStudyMaterials(
  content: string,
  title: string,
  maxFlashcards = 999,
  maxQuizQuestions = 999,
  shouldSkim = false,
  isUnlimited = false, // Add unlimited flag
) {
  // If file is large (>200MB equivalent in content), skim it first
  let processedContent = content
  if (shouldSkim && content.length > 100000) {
    // Roughly 200MB of text content
    processedContent = await skimLargeContent(content, title)
  }

  // For unlimited plans, set reasonable maximums to prevent excessive generation
  const effectiveMaxFlashcards = isUnlimited ? (shouldSkim ? 200 : 500) : maxFlashcards
  const effectiveMaxQuizQuestions = isUnlimited ? (shouldSkim ? 100 : 200) : maxQuizQuestions

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 20000, // Set 20k token limit for Ultimate Plan
    messages: [
      {
        role: "system",
        content: `You are an expert study assistant. Generate comprehensive study materials from the provided content.

        IMPORTANT LIMITS:
        - Generate a maximum of ${effectiveMaxFlashcards} flashcards
        - Generate a maximum of ${effectiveMaxQuizQuestions} quiz questions
        ${isUnlimited ? "- You have unlimited generation capability, create as many quality materials as the content supports" : ""}

        FLASHCARD REQUIREMENTS:
        - Question: Key concept or important information (max 3 sentences, preferably shorter)
        - Answer: Helpful and understandable explanation (max 3 sentences, try to be concise)
        - Focus on the most important concepts, definitions, and facts

        QUIZ QUESTION REQUIREMENTS:
        - Question: Clear and logical (one sentence preferred)
        - 4 options (A-D): One correct answer, three plausible but incorrect options related to the topic
        - Correct answer: Must be logical and clearly correct
        - Explanation: Brief explanation for why the answer is correct (regardless of user's choice)
        - Wrong answers should be related to the topic but clearly incorrect when analyzed

        Return a JSON object with three sections:
        1. "notes": Array of note objects with 'title' and 'content' fields
        2. "flashcards": Array of flashcard objects with 'front' and 'back' fields
        3. "quiz": Array of quiz objects with 'question', 'options' (array of 4 strings), 'correctAnswer' (index 0-3), and 'explanation' fields

        ${
          isUnlimited
            ? "Extract maximum value from the content. Generate comprehensive materials covering all important topics."
            : "Extract maximum value from the content while respecting the limits. Prioritize the most important and useful information."
        }`,
      },
      {
        role: "user",
        content: `Generate study materials from this content titled "${title}":\n\n${processedContent}`,
      },
    ],
    response_format: { type: "json_object" },
  })

  const result = JSON.parse(response.choices[0].message.content || '{"notes": [], "flashcards": [], "quiz": []}')

  // For non-unlimited plans, enforce strict limits
  if (!isUnlimited) {
    if (result.flashcards && result.flashcards.length > maxFlashcards) {
      result.flashcards = result.flashcards.slice(0, maxFlashcards)
    }
    if (result.quiz && result.quiz.length > maxQuizQuestions) {
      result.quiz = result.quiz.slice(0, maxQuizQuestions)
    }
  }

  return result
}

// Function to skim large content and extract important parts
async function skimLargeContent(content: string, title: string): Promise<string> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 8000, // Use portion of token limit for skimming
    messages: [
      {
        role: "system",
        content: `You are an expert content analyzer. The user has uploaded a large file that needs to be processed efficiently. 

        Your task is to skim through the content and extract the most important parts, including:
        - Key concepts and definitions
        - Important facts and figures
        - Main topics and subtopics
        - Critical information for studying
        - Essential formulas, processes, or procedures

        Reduce the content to about 30-40% of its original length while preserving all the important educational value. 
        Remove redundant information, examples that don't add educational value, and verbose explanations.
        Keep the essential information that students need to learn and understand the subject.
        
        Focus on creating comprehensive study materials from the key concepts you extract.`,
      },
      {
        role: "user",
        content: `Please skim and extract the most important parts from this content titled "${title}":\n\n${content}`,
      },
    ],
  })

  return response.choices[0].message.content || content
}

// Chat function for interactive Q&A with usage limits
export async function chatWithContent(message: string, context: string, isUnlimited = false) {
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: isUnlimited ? 2000 : 1000, // More tokens for unlimited users
    messages: [
      {
        role: "system",
        content: `You are a helpful AI tutor. Answer questions about the study material provided in the context. 
        Be educational, clear, and encouraging. Reference specific parts of the material when relevant.
        Keep your responses concise but informative.
        
        Study Material Context:
        ${context}`,
      },
      {
        role: "user",
        content: message,
      },
    ],
  })

  return response.choices[0].message.content || "I'm sorry, I couldn't generate a response."
}
