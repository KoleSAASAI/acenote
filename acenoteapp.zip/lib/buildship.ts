interface BuildShipWorkflowResponse {
  success: boolean
  data?: any
  error?: string
  workflowId?: string
}

interface BuildShipConfig {
  apiKey: string
  baseUrl: string
}

class BuildShipClient {
  private config: BuildShipConfig

  constructor() {
    this.config = {
      apiKey: process.env.BUILDSHIP_API_KEY || "",
      baseUrl: process.env.BUILDSHIP_BASE_URL || "https://api.buildship.app",
    }
  }

  private async makeRequest(endpoint: string, data: any): Promise<BuildShipWorkflowResponse> {
    try {
      const response = await fetch(`${this.config.baseUrl}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.config.apiKey}`,
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error(`BuildShip API error: ${response.status}`)
      }

      const result = await response.json()
      return { success: true, data: result }
    } catch (error) {
      console.error("BuildShip request failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  // Document Processing Workflow
  async processDocument(params: {
    userId: string
    fileName: string
    fileContent: string
    fileType: string
    planType: string
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/document-processor", {
      userId: params.userId,
      fileName: params.fileName,
      fileContent: params.fileContent,
      fileType: params.fileType,
      planType: params.planType,
      timestamp: new Date().toISOString(),
    })
  }

  // YouTube Video Processing Workflow
  async processYouTubeVideo(params: {
    userId: string
    videoUrl: string
    planType: string
    maxDuration: number
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/youtube-processor", {
      userId: params.userId,
      videoUrl: params.videoUrl,
      planType: params.planType,
      maxDuration: params.maxDuration,
      timestamp: new Date().toISOString(),
    })
  }

  // Audio Processing Workflow
  async processAudio(params: {
    userId: string
    audioFile: string
    fileName: string
    planType: string
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/audio-processor", {
      userId: params.userId,
      audioFile: params.audioFile,
      fileName: params.fileName,
      planType: params.planType,
      timestamp: new Date().toISOString(),
    })
  }

  // AI Study Materials Generation Workflow
  async generateStudyMaterials(params: {
    userId: string
    content: string
    title: string
    maxFlashcards: number
    maxQuizQuestions: number
    planType: string
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/ai-study-generator", {
      userId: params.userId,
      content: params.content,
      title: params.title,
      maxFlashcards: params.maxFlashcards,
      maxQuizQuestions: params.maxQuizQuestions,
      planType: params.planType,
      timestamp: new Date().toISOString(),
    })
  }

  // Email Notification Workflow
  async sendNotification(params: {
    userId: string
    email: string
    type: "welcome" | "processing_complete" | "upgrade_reminder" | "limit_reached"
    data?: any
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/email-notifications", {
      userId: params.userId,
      email: params.email,
      notificationType: params.type,
      data: params.data,
      timestamp: new Date().toISOString(),
    })
  }

  // User Analytics Workflow
  async trackUserActivity(params: {
    userId: string
    action: string
    metadata?: any
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/user-analytics", {
      userId: params.userId,
      action: params.action,
      metadata: params.metadata,
      timestamp: new Date().toISOString(),
    })
  }

  // Subscription Management Workflow
  async handleSubscriptionChange(params: {
    userId: string
    oldPlan: string
    newPlan: string
    email: string
  }): Promise<BuildShipWorkflowResponse> {
    return this.makeRequest("/workflows/subscription-manager", {
      userId: params.userId,
      oldPlan: params.oldPlan,
      newPlan: params.newPlan,
      email: params.email,
      timestamp: new Date().toISOString(),
    })
  }
}

export const buildShipClient = new BuildShipClient()
