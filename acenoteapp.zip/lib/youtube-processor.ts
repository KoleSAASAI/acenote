import { exec } from "child_process"
import { promisify } from "util"
import { unlink } from "fs/promises"
import { join } from "path"
import { tmpdir } from "os"
import OpenAI from "openai"

const execAsync = promisify(exec)

if (!process.env.OPENAI_API_KEY) {
  throw new Error("Missing OPENAI_API_KEY environment variable")
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export interface YouTubeVideoInfo {
  title: string
  duration: number // in seconds
  url: string
}

export async function getYouTubeVideoInfo(url: string): Promise<YouTubeVideoInfo> {
  try {
    // Get video info using yt-dlp
    const { stdout } = await execAsync(`yt-dlp --print "%(title)s|%(duration)s" "${url}"`)

    const [title, durationStr] = stdout.trim().split("|")
    const duration = Number.parseInt(durationStr) || 0

    return {
      title: title || "Unknown Title",
      duration,
      url,
    }
  } catch (error) {
    console.error("Error getting YouTube video info:", error)
    throw new Error("Failed to get video information")
  }
}

export async function downloadYouTubeAudio(url: string): Promise<string> {
  try {
    const tempDir = tmpdir()
    const outputPath = join(tempDir, `youtube_audio_${Date.now()}.mp3`)

    // Download audio using yt-dlp
    await execAsync(`yt-dlp -x --audio-format mp3 --audio-quality 0 -o "${outputPath}" "${url}"`)

    return outputPath
  } catch (error) {
    console.error("Error downloading YouTube audio:", error)
    throw new Error("Failed to download audio from YouTube video")
  }
}

export async function transcribeAudio(audioPath: string): Promise<string> {
  try {
    // Read the audio file
    const audioFile = await import("fs").then((fs) => fs.createReadStream(audioPath))

    // Transcribe using OpenAI gpt-4o-mini-transcribe (cheaper alternative to Whisper-1)
    const transcription = await openai.audio.transcriptions.create({
      file: audioFile,
      model: "gpt-4o-mini-transcribe", // Using the cheaper transcription model
      language: "en", // You can make this dynamic based on video
      response_format: "text", // Get plain text response
    })

    return transcription
  } catch (error) {
    console.error("Error transcribing audio:", error)
    throw new Error("Failed to transcribe audio")
  }
}

export async function processYouTubeVideo(url: string): Promise<{
  title: string
  duration: number
  transcript: string
}> {
  let audioPath: string | null = null

  try {
    // Get video info first
    const videoInfo = await getYouTubeVideoInfo(url)

    // Download audio
    audioPath = await downloadYouTubeAudio(url)

    // Transcribe audio using gpt-4o-mini-transcribe
    const transcript = await transcribeAudio(audioPath)

    return {
      title: videoInfo.title,
      duration: videoInfo.duration,
      transcript,
    }
  } catch (error) {
    console.error("Error processing YouTube video:", error)
    throw error
  } finally {
    // Clean up temporary audio file
    if (audioPath) {
      try {
        await unlink(audioPath)
      } catch (cleanupError) {
        console.error("Error cleaning up audio file:", cleanupError)
      }
    }
  }
}
