import { supabase } from "./supabase"

export interface SubscriptionPlan {
  id: string
  name: string
  description: string
  price_monthly: number
  price_yearly: number
  max_uploads_per_month: number
  max_uploads_per_day: number
  max_file_size_mb: number
  max_youtube_duration_minutes: number // Total minutes per month, not per video
  max_flashcards: number
  max_quiz_questions: number
  max_chat_interactions: number
  max_tokens_per_month: number
}

export interface UserSubscription {
  id: string
  user_id: string
  plan_id: string
  status: string
  current_period_end: string
  plan: SubscriptionPlan
}

export interface UserUsage {
  uploads_this_month: number
  uploads_this_day: number
  chat_interactions_this_month: number
  youtube_minutes_used_this_month: number // Track total YouTube minutes used
  last_upload_date: string
  last_chat_date: string
}

export async function getUserSubscription(userId: string): Promise<UserSubscription | null> {
  const { data, error } = await supabase
    .from("user_subscriptions")
    .select(`
      *,
      plan:subscription_plans(*)
    `)
    .eq("user_id", userId)
    .eq("status", "active")
    .single()

  if (error) {
    console.error("Error fetching user subscription:", error)
    return null
  }

  return data
}

export async function getUserUsage(userId: string): Promise<UserUsage | null> {
  const currentMonth = new Date().toISOString().slice(0, 7) // YYYY-MM format

  const { data, error } = await supabase
    .from("user_usage")
    .select("*")
    .eq("user_id", userId)
    .eq("month_year", currentMonth)
    .single()

  if (error) {
    console.error("Error fetching user usage:", error)
    return null
  }

  return data
}

export async function checkYouTubeTranscriptionLimit(
  userId: string,
  videoDurationMinutes: number,
): Promise<{
  canTranscribe: boolean
  reason?: string
  remainingMinutes: number
  plan: SubscriptionPlan | null
}> {
  const subscription = await getUserSubscription(userId)
  const usage = await getUserUsage(userId)

  if (!subscription) {
    return { canTranscribe: false, reason: "No subscription found", remainingMinutes: 0, plan: null }
  }

  const plan = subscription.plan as SubscriptionPlan
  const currentUsage = usage?.youtube_minutes_used_this_month || 0
  const remainingMinutes = plan.max_youtube_duration_minutes - currentUsage

  // Check if adding this video would exceed the monthly limit
  if (currentUsage + videoDurationMinutes > plan.max_youtube_duration_minutes) {
    return {
      canTranscribe: false,
      reason: `YouTube transcription limit exceeded. You have ${remainingMinutes} minutes remaining this month.`,
      remainingMinutes,
      plan,
    }
  }

  return {
    canTranscribe: true,
    remainingMinutes: remainingMinutes - videoDurationMinutes,
    plan,
  }
}

export async function incrementYouTubeUsage(userId: string, durationMinutes: number): Promise<void> {
  const currentMonth = new Date().toISOString().slice(0, 7)
  const today = new Date().toISOString().slice(0, 10)

  const { data: existingUsage } = await supabase
    .from("user_usage")
    .select("*")
    .eq("user_id", userId)
    .eq("month_year", currentMonth)
    .single()

  if (existingUsage) {
    const isNewDay = existingUsage.last_upload_date !== today
    await supabase
      .from("user_usage")
      .update({
        uploads_this_month: existingUsage.uploads_this_month + 1,
        uploads_this_day: isNewDay ? 1 : existingUsage.uploads_this_day + 1,
        youtube_minutes_used_this_month: existingUsage.youtube_minutes_used_this_month + durationMinutes,
        last_upload_date: today,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .eq("month_year", currentMonth)
  } else {
    await supabase.from("user_usage").insert({
      user_id: userId,
      month_year: currentMonth,
      uploads_this_month: 1,
      uploads_this_day: 1,
      youtube_minutes_used_this_month: durationMinutes,
      last_upload_date: today,
    })
  }
}

export async function checkUploadLimits(
  userId: string,
  fileSize: number,
  fileType: string,
  youtubeDuration?: number,
): Promise<{
  canUpload: boolean
  reason?: string
  plan: SubscriptionPlan | null
}> {
  const subscription = await getUserSubscription(userId)
  const usage = await getUserUsage(userId)

  if (!subscription) {
    return { canUpload: false, reason: "No subscription found", plan: null }
  }

  const plan = subscription.plan as SubscriptionPlan

  // For YouTube uploads, check transcription time limit instead of per-video duration
  if (fileType === "youtube" && youtubeDuration) {
    const transcriptionCheck = await checkYouTubeTranscriptionLimit(userId, youtubeDuration)
    if (!transcriptionCheck.canTranscribe) {
      return {
        canUpload: false,
        reason: transcriptionCheck.reason,
        plan,
      }
    }
  }

  // Check file size limit (skip for YouTube)
  if (fileType !== "youtube") {
    const fileSizeMB = fileSize / (1024 * 1024)
    if (fileSizeMB > plan.max_file_size_mb) {
      return {
        canUpload: false,
        reason: `File size (${fileSizeMB.toFixed(1)}MB) exceeds limit of ${plan.max_file_size_mb}MB`,
        plan,
      }
    }
  }

  // Check monthly upload limit
  if (usage && usage.uploads_this_month >= plan.max_uploads_per_month) {
    return {
      canUpload: false,
      reason: `Monthly upload limit of ${plan.max_uploads_per_month} reached`,
      plan,
    }
  }

  // Check daily upload limit
  const today = new Date().toISOString().slice(0, 10)
  if (usage && usage.last_upload_date === today && usage.uploads_this_day >= plan.max_uploads_per_day) {
    return {
      canUpload: false,
      reason: `Daily upload limit of ${plan.max_uploads_per_day} reached`,
      plan,
    }
  }

  return { canUpload: true, plan }
}

export async function checkChatLimits(userId: string): Promise<{
  canChat: boolean
  reason?: string
  remaining: number
}> {
  const subscription = await getUserSubscription(userId)
  const usage = await getUserUsage(userId)

  if (!subscription) {
    return { canChat: false, reason: "No subscription found", remaining: 0 }
  }

  const plan = subscription.plan as SubscriptionPlan
  const currentUsage = usage?.chat_interactions_this_month || 0

  if (currentUsage >= plan.max_chat_interactions) {
    return {
      canChat: false,
      reason: `Monthly chat limit of ${plan.max_chat_interactions} reached`,
      remaining: 0,
    }
  }

  return {
    canChat: true,
    remaining: plan.max_chat_interactions - currentUsage,
  }
}

export async function incrementChatUsage(userId: string): Promise<void> {
  const currentMonth = new Date().toISOString().slice(0, 7)
  const today = new Date().toISOString().slice(0, 10)

  const { data: existingUsage } = await supabase
    .from("user_usage")
    .select("*")
    .eq("user_id", userId)
    .eq("month_year", currentMonth)
    .single()

  if (existingUsage) {
    await supabase
      .from("user_usage")
      .update({
        chat_interactions_this_month: existingUsage.chat_interactions_this_month + 1,
        last_chat_date: today,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .eq("month_year", currentMonth)
  } else {
    await supabase.from("user_usage").insert({
      user_id: userId,
      month_year: currentMonth,
      chat_interactions_this_month: 1,
      last_chat_date: today,
    })
  }
}

export async function incrementUploadUsage(userId: string): Promise<void> {
  const currentMonth = new Date().toISOString().slice(0, 7)
  const today = new Date().toISOString().slice(0, 10)

  const { data: existingUsage } = await supabase
    .from("user_usage")
    .select("*")
    .eq("user_id", userId)
    .eq("month_year", currentMonth)
    .single()

  if (existingUsage) {
    const isNewDay = existingUsage.last_upload_date !== today
    await supabase
      .from("user_usage")
      .update({
        uploads_this_month: existingUsage.uploads_this_month + 1,
        uploads_this_day: isNewDay ? 1 : existingUsage.uploads_this_day + 1,
        last_upload_date: today,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .eq("month_year", currentMonth)
  } else {
    await supabase.from("user_usage").insert({
      user_id: userId,
      month_year: currentMonth,
      uploads_this_month: 1,
      uploads_this_day: 1,
      last_upload_date: today,
    })
  }
}
