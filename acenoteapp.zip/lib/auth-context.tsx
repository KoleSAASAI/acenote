"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState, useRef } from "react"
import type { User } from "@supabase/supabase-js"
import { supabase, isSupabaseConfigured } from "./supabase"

interface AuthContextType {
  user: User | null
  loading: boolean
  signInWithGoogle: () => Promise<void>
  signUpWithEmail: (
    email: string,
    password: string,
    firstName: string,
    lastName: string,
  ) => Promise<{ error: string | null }>
  signInWithEmail: (email: string, password: string) => Promise<{ error: string | null }>
  signOut: () => Promise<void>
  error: string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [initialized, setInitialized] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    console.log("🔄 Auth context initializing...")

    if (!isSupabaseConfigured()) {
      console.error("❌ Supabase not configured")
      setError("Supabase is not configured. Please add your environment variables.")
      setLoading(false)
      setInitialized(true)
      return
    }

    let mounted = true

    // Set a maximum timeout to prevent infinite loading (5 seconds)
    timeoutRef.current = setTimeout(() => {
      if (mounted && !initialized) {
        console.warn("⚠️ Auth initialization timeout - forcing completion")
        setLoading(false)
        setInitialized(true)
      }
    }, 5000)

    // Get initial session
    const initializeAuth = async () => {
      try {
        console.log("🔍 Getting initial session...")

        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        if (!mounted) return

        if (sessionError) {
          console.error("❌ Session error:", sessionError)
          setError(`Authentication error: ${sessionError.message}`)
          setUser(null)
        } else if (session?.user) {
          console.log("✅ Session found for user:", session.user.email)
          setUser(session.user)
          setError(null)
          // Don't await profile creation to avoid blocking
          createOrUpdateProfile(session.user).catch(console.error)
        } else {
          console.log("ℹ️ No active session found")
          setUser(null)
          setError(null)
        }
      } catch (error) {
        if (!mounted) return
        console.error("❌ Error initializing auth:", error)
        setError("Failed to initialize authentication")
        setUser(null)
      } finally {
        if (mounted) {
          console.log("✅ Auth initialization complete")
          setLoading(false)
          setInitialized(true)
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current)
            timeoutRef.current = null
          }
        }
      }
    }

    initializeAuth()

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return

      console.log("🔄 Auth state changed:", event, session?.user?.email || "no user")

      try {
        switch (event) {
          case "SIGNED_IN":
            if (session?.user) {
              console.log("✅ User signed in:", session.user.email)
              setUser(session.user)
              setError(null)
              // Don't await profile creation to avoid blocking
              createOrUpdateProfile(session.user).catch(console.error)
            }
            break

          case "SIGNED_OUT":
            console.log("👋 User signed out")
            setUser(null)
            setError(null)
            break

          case "TOKEN_REFRESHED":
            if (session?.user) {
              console.log("🔄 Token refreshed for:", session.user.email)
              setUser(session.user)
              setError(null)
            }
            break

          case "USER_UPDATED":
            if (session?.user) {
              console.log("👤 User updated:", session.user.email)
              setUser(session.user)
              setError(null)
            }
            break

          default:
            console.log(`🔄 Auth event: ${event}`)
        }
      } catch (error) {
        console.error("❌ Error handling auth state change:", error)
        setError("Authentication error occurred")
      }

      // Always ensure loading is false after auth state changes (if initialized)
      if (initialized && mounted) {
        setLoading(false)
      }
    })

    return () => {
      console.log("🧹 Cleaning up auth context")
      mounted = false
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
        timeoutRef.current = null
      }
      subscription.unsubscribe()
    }
  }, [initialized])

  // Create or update user profile in database
  const createOrUpdateProfile = async (user: User, additionalData?: { firstName?: string; lastName?: string }) => {
    try {
      console.log("👤 Creating/updating profile for:", user.email)

      const { data: existingProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (!existingProfile) {
        // Create new profile
        const fullName =
          additionalData?.firstName && additionalData?.lastName
            ? `${additionalData.firstName} ${additionalData.lastName}`
            : user.user_metadata?.full_name ||
              user.user_metadata?.name ||
              (user.user_metadata?.first_name && user.user_metadata?.last_name
                ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}`
                : "")

        console.log("📝 Creating new profile with name:", fullName)

        const { error: insertError } = await supabase.from("profiles").insert({
          id: user.id,
          email: user.email,
          full_name: fullName,
          avatar_url: user.user_metadata?.avatar_url || user.user_metadata?.picture || "",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (insertError) {
          console.error("❌ Error creating profile:", insertError)
        } else {
          console.log("✅ Profile created successfully for:", fullName || user.email)
        }
      } else {
        // Update existing profile with latest data
        const updatedFullName =
          user.user_metadata?.full_name ||
          user.user_metadata?.name ||
          (user.user_metadata?.first_name && user.user_metadata?.last_name
            ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}`
            : existingProfile.full_name)

        console.log("🔄 Updating existing profile with name:", updatedFullName)

        const { error: updateError } = await supabase
          .from("profiles")
          .update({
            email: user.email,
            full_name: updatedFullName,
            avatar_url: user.user_metadata?.avatar_url || user.user_metadata?.picture || existingProfile.avatar_url,
            updated_at: new Date().toISOString(),
          })
          .eq("id", user.id)

        if (updateError) {
          console.error("❌ Error updating profile:", updateError)
        } else {
          console.log("✅ Profile updated successfully for:", updatedFullName || user.email)
        }
      }
    } catch (error) {
      console.error("❌ Error creating/updating profile:", error)
    }
  }

  const signInWithGoogle = async () => {
    if (!isSupabaseConfigured()) {
      setError("Supabase is not configured. Please add your environment variables.")
      return
    }

    try {
      setError(null)

      // Use the auth callback page for better handling
      const redirectUrl = `${window.location.origin}/auth/callback`
      console.log("🔗 OAuth redirect URL:", redirectUrl)

      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: redirectUrl,
          queryParams: {
            access_type: "offline",
            prompt: "consent",
          },
        },
      })

      if (error) {
        console.error("❌ OAuth error:", error)
        setError(`Sign-in failed: ${error.message}`)
      }
    } catch (error: any) {
      console.error("❌ Error signing in with Google:", error)
      setError(`Sign-in failed: ${error.message || "Unknown error occurred"}`)
    }
  }

  const signUpWithEmail = async (email: string, password: string, firstName: string, lastName: string) => {
    if (!isSupabaseConfigured()) {
      return { error: "Supabase is not configured. Please add your environment variables." }
    }

    try {
      setError(null)

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            full_name: `${firstName} ${lastName}`,
          },
        },
      })

      if (error) {
        console.error("❌ Email signup error:", error)
        setError(error.message)
        return { error: error.message }
      }

      if (data.user) {
        // Create profile with the additional data
        await createOrUpdateProfile(data.user, { firstName, lastName })

        // Check if email confirmation is required
        if (!data.session) {
          return { error: null } // Success, but email confirmation required
        }
      }

      return { error: null }
    } catch (error: any) {
      console.error("❌ Error signing up with email:", error)
      const errorMessage = error.message || "Unknown error occurred"
      setError(errorMessage)
      return { error: errorMessage }
    }
  }

  const signInWithEmail = async (email: string, password: string) => {
    if (!isSupabaseConfigured()) {
      return { error: "Supabase is not configured. Please add your environment variables." }
    }

    try {
      setError(null)

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("❌ Email signin error:", error)
        setError(error.message)
        return { error: error.message }
      }

      return { error: null }
    } catch (error: any) {
      console.error("❌ Error signing in with email:", error)
      const errorMessage = error.message || "Unknown error occurred"
      setError(errorMessage)
      return { error: errorMessage }
    }
  }

  const signOut = async () => {
    try {
      setError(null)
      const { error } = await supabase.auth.signOut()
      if (error) {
        console.error("❌ Error signing out:", error)
        setError(`Sign out failed: ${error.message}`)
      }
    } catch (error: any) {
      console.error("❌ Error signing out:", error)
      setError(`Sign out failed: ${error.message || "Unknown error occurred"}`)
    }
  }

  // Debug logging
  console.log("🔍 Auth Context State:", {
    hasUser: !!user,
    userEmail: user?.email,
    loading,
    initialized,
    error: !!error,
  })

  const value = {
    user,
    loading,
    signInWithGoogle,
    signUpWithEmail,
    signInWithEmail,
    signOut,
    error,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
