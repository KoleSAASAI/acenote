"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, ChevronRight, RotateCcw, Brain, FileText, BookOpen, MessageCircle } from "lucide-react"

const flashcards = [
  {
    id: 1,
    question: "What is the primary function of mitochondria in cells?",
    answer:
      "Mitochondria are the powerhouses of the cell, responsible for producing ATP (adenosine triphosphate) through cellular respiration, which provides energy for cellular processes.",
  },
  {
    id: 2,
    question: "Explain the difference between DNA and RNA.",
    answer:
      "DNA (deoxyribonucleic acid) is double-stranded, contains deoxyribose sugar, and stores genetic information. RNA (ribonucleic acid) is single-stranded, contains ribose sugar, and is involved in protein synthesis and gene expression.",
  },
  {
    id: 3,
    question: "What is photosynthesis and where does it occur?",
    answer:
      "Photosynthesis is the process by which plants convert light energy into chemical energy (glucose) using carbon dioxide and water. It occurs primarily in the chloroplasts of plant cells, specifically in the thylakoid membranes.",
  },
  {
    id: 4,
    question: "Define osmosis and provide an example.",
    answer:
      "Osmosis is the movement of water molecules across a semipermeable membrane from an area of lower solute concentration to higher solute concentration. Example: Water moving into plant roots from soil.",
  },
  {
    id: 5,
    question: "What are the four main types of biological macromolecules?",
    answer:
      "The four main types are: 1) Carbohydrates (energy storage and structure), 2) Lipids (energy storage and membranes), 3) Proteins (enzymes and structure), and 4) Nucleic acids (genetic information).",
  },
]

export default function FlashcardStudy() {
  const [currentCard, setCurrentCard] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [reviewedCards, setReviewedCards] = useState<Set<number>>(new Set())
  const [activeTab, setActiveTab] = useState("flashcards")
  const [xp, setXp] = useState(0)
  const [streak, setStreak] = useState(0)

  const handleCardClick = () => {
    setIsFlipped(!isFlipped)
    if (!isFlipped) {
      setReviewedCards((prev) => new Set([...prev, currentCard]))
    }
  }

  const handlePrevious = () => {
    if (currentCard > 0) {
      setCurrentCard(currentCard - 1)
      setIsFlipped(false)
    }
  }

  const handleNext = () => {
    if (currentCard < flashcards.length - 1) {
      setCurrentCard(currentCard + 1)
      setIsFlipped(false)
    }
  }

  const handleShowAnswer = () => {
    setIsFlipped(true)
    setReviewedCards((prev) => new Set([...prev, currentCard]))
    setXp(xp + 10)
    setStreak(streak + 1)
  }

  const resetProgress = () => {
    setCurrentCard(0)
    setIsFlipped(false)
    setReviewedCards(new Set())
    setXp(0)
    setStreak(0)
  }

  const progressPercentage = (reviewedCards.size / flashcards.length) * 100
  const remainingCards = flashcards.length - reviewedCards.size

  return (
    <div className="w-full" style={{ fontFamily: "Inter, sans-serif" }}>
      <div className="max-w-4xl mx-auto">
        {/* Top Navigation Tabs */}
        <div className="mb-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList
              className="grid w-full grid-cols-4 h-12 mb-8"
              style={{ backgroundColor: "#1E293B", border: "1px solid #374151" }}
            >
              <TabsTrigger
                value="notes"
                className="flex items-center gap-2 text-[#F8FAFC] data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A] hover:bg-[#374151]"
              >
                <FileText className="h-4 w-4" />
                Notes
              </TabsTrigger>
              <TabsTrigger
                value="flashcards"
                className="flex items-center gap-2 text-[#F8FAFC] data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A] hover:bg-[#374151]"
              >
                <Brain className="h-4 w-4" />
                Flashcards
              </TabsTrigger>
              <TabsTrigger
                value="quiz"
                className="flex items-center gap-2 text-[#F8FAFC] data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A] hover:bg-[#374151]"
              >
                <BookOpen className="h-4 w-4" />
                Quiz
              </TabsTrigger>
              <TabsTrigger
                value="chat"
                className="flex items-center gap-2 text-[#F8FAFC] data-[state=active]:bg-[#3EF2B5] data-[state=active]:text-[#0F172A] hover:bg-[#374151]"
              >
                <MessageCircle className="h-4 w-4" />
                Chat
              </TabsTrigger>
            </TabsList>

            <TabsContent value="flashcards" className="mt-0" style={{ backgroundColor: "#0F172A" }}>
              {/* Progress Section */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-semibold" style={{ color: "#F8FAFC" }}>
                    Biology Flashcards
                  </h2>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-sm" style={{ color: "#94A3B8" }}>
                          XP
                        </div>
                        <div className="text-lg font-bold" style={{ color: "#3EF2B5" }}>
                          {xp}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm" style={{ color: "#94A3B8" }}>
                          Streak
                        </div>
                        <div className="text-lg font-bold" style={{ color: "#3EF2B5" }}>
                          {streak}
                        </div>
                      </div>
                    </div>
                    <Badge className="px-3 py-1" style={{ backgroundColor: "#3EF2B5", color: "#0F172A" }}>
                      {reviewedCards.size} reviewed
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={resetProgress}
                      className="border-[#374151] text-[#F8FAFC] hover:bg-[#1E293B] hover:border-[#3EF2B5]"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm" style={{ color: "#94A3B8" }}>
                      Card {currentCard + 1} of {flashcards.length}
                    </span>
                    <span className="text-sm font-medium" style={{ color: "#3EF2B5" }}>
                      {Math.round(progressPercentage)}% Complete
                    </span>
                  </div>
                  <div className="w-full bg-[#1E293B] rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500 ease-out"
                      style={{
                        width: `${progressPercentage}%`,
                        backgroundColor: "#3EF2B5",
                        boxShadow: "0 0 8px rgba(62, 242, 181, 0.4)",
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Flashcard Display */}
              <div className="flex justify-center mb-8">
                <Card
                  className="w-full max-w-2xl h-80 cursor-pointer transition-all duration-300 hover:scale-[1.01] group"
                  onClick={handleCardClick}
                  style={{
                    backgroundColor: "#1E293B",
                    border: "1px solid #374151",
                    boxShadow: isFlipped
                      ? "0 0 25px rgba(62, 242, 181, 0.2), 0 8px 32px rgba(0, 0, 0, 0.3)"
                      : "0 8px 32px rgba(0, 0, 0, 0.3)",
                  }}
                >
                  <CardContent className="h-full flex flex-col items-center justify-center p-8 text-center">
                    <div className="mb-6">
                      <Badge
                        className="text-sm font-medium px-4 py-1.5"
                        style={{
                          backgroundColor: isFlipped ? "#1DB58B" : "#67F9DC",
                          color: "#0F172A",
                        }}
                      >
                        {isFlipped ? "Answer" : "Question"}
                      </Badge>
                    </div>

                    <div className="flex-1 flex items-center justify-center">
                      <div className={`transition-all duration-300 ${isFlipped ? "animate-in fade-in-50" : ""}`}>
                        <p className="text-xl leading-relaxed font-medium" style={{ color: "#F8FAFC" }}>
                          {isFlipped ? flashcards[currentCard].answer : flashcards[currentCard].question}
                        </p>
                      </div>
                    </div>

                    {!isFlipped && (
                      <div className="mt-6">
                        <p className="text-sm" style={{ color: "#94A3B8" }}>
                          Click to reveal answer
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Navigation Controls */}
              <div className="flex justify-center items-center gap-4 mb-8">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentCard === 0}
                  className="px-6 py-3 border-[#374151] text-[#F8FAFC] hover:bg-[#1E293B] hover:border-[#3EF2B5] hover:shadow-lg hover:shadow-[#3EF2B5]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>

                <Button
                  onClick={handleShowAnswer}
                  disabled={isFlipped}
                  className="px-8 py-3 font-medium transition-all duration-200 hover:shadow-lg hover:shadow-[#1DB58B]/30 disabled:opacity-50"
                  style={{
                    backgroundColor: isFlipped ? "#1DB58B" : "#3EF2B5",
                    color: "#0F172A",
                  }}
                >
                  {isFlipped ? "Answer Shown" : "Show Answer"}
                </Button>

                <Button
                  variant="outline"
                  onClick={handleNext}
                  disabled={currentCard === flashcards.length - 1}
                  className="px-6 py-3 border-[#374151] text-[#F8FAFC] hover:bg-[#1E293B] hover:border-[#3EF2B5] hover:shadow-lg hover:shadow-[#3EF2B5]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>

              {/* Statistics Section */}
              <Card
                className="w-full"
                style={{
                  backgroundColor: "#1E293B",
                  border: "1px solid #374151",
                }}
              >
                <CardContent className="p-6">
                  <div className="grid grid-cols-3 gap-6 text-center">
                    <div className="space-y-2">
                      <div className="text-3xl font-bold" style={{ color: "#3EF2B5" }}>
                        {flashcards.length}
                      </div>
                      <div className="text-sm font-medium" style={{ color: "#F8FAFC" }}>
                        Total Cards
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-3xl font-bold" style={{ color: "#3EF2B5" }}>
                        {reviewedCards.size}
                      </div>
                      <div className="text-sm font-medium" style={{ color: "#F8FAFC" }}>
                        Reviewed
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-3xl font-bold" style={{ color: "#3EF2B5" }}>
                        {remainingCards}
                      </div>
                      <div className="text-sm font-medium" style={{ color: "#F8FAFC" }}>
                        Remaining
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Placeholder content for other tabs */}
            <TabsContent value="notes" className="mt-0" style={{ backgroundColor: "#0F172A" }}>
              <Card style={{ backgroundColor: "#1E293B", border: "1px solid #374151" }}>
                <CardContent className="p-8 text-center">
                  <FileText className="h-16 w-16 mx-auto mb-4" style={{ color: "#3EF2B5" }} />
                  <h3 className="text-xl font-semibold mb-2" style={{ color: "#F8FAFC" }}>
                    Notes Section
                  </h3>
                  <p style={{ color: "#94A3B8" }}>Your study notes will appear here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="quiz" className="mt-0" style={{ backgroundColor: "#0F172A" }}>
              <Card style={{ backgroundColor: "#1E293B", border: "1px solid #374151" }}>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-16 w-16 mx-auto mb-4" style={{ color: "#3EF2B5" }} />
                  <h3 className="text-xl font-semibold mb-2" style={{ color: "#F8FAFC" }}>
                    Quiz Section
                  </h3>
                  <p style={{ color: "#94A3B8" }}>Practice quizzes will be available here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat" className="mt-0" style={{ backgroundColor: "#0F172A" }}>
              <Card style={{ backgroundColor: "#1E293B", border: "1px solid #374151" }}>
                <CardContent className="p-8 text-center">
                  <MessageCircle className="h-16 w-16 mx-auto mb-4" style={{ color: "#3EF2B5" }} />
                  <h3 className="text-xl font-semibold mb-2" style={{ color: "#F8FAFC" }}>
                    AI Chat Assistant
                  </h3>
                  <p style={{ color: "#94A3B8" }}>Ask questions about your study materials</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
